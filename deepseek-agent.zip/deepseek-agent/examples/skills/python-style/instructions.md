# Python house style

When you write or change Python code in this project:

1. Follow PEP 8; line length 100.
2. Add type hints to every new function signature.
3. Prefer `pathlib.Path` over `os.path` in new code.
4. Raise specific exceptions; never use a bare `except:`.
5. Put each change behind a test: if a test file exists for the module, extend it; otherwise create `tests/test_<module>.py`.
6. After editing, run the tests with `python -m unittest` (or `pytest` if the project already uses it) before reporting success.
