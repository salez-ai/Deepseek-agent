# Project notes

You can keep a notes file for this project.

- Use `note_add` when you make a design decision, discover something surprising, or leave work unfinished. Keep notes short and factual.
- Use `note_list` at the start of a task to see what earlier sessions recorded.
- Never put secrets (keys, passwords, tokens) in notes.

Example:

```tool
name: note_add
title: Chose SQLite for storage
=====BODY=====
The app is single-user and offline, so SQLite avoids a server. Revisit if sync is needed.
=====END=====
```
