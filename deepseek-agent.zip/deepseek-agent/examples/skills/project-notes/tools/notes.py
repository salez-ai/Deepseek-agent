"""project-notes tools. Protocol: JSON on stdin, text on stdout."""
import json
import sys
from datetime import datetime
from pathlib import Path

req = json.load(sys.stdin)
notes = Path(req["project_dir"]) / ".agent-notes.md"

if req["tool"] == "note_add":
    title = req["params"]["title"].strip().replace("\n", " ")
    text = (req["body"] or "").strip()
    stamp = datetime.now().strftime("%Y-%m-%d %H:%M")
    with notes.open("a", encoding="utf-8") as f:
        f.write(f"## {title}\n*{stamp}*\n\n{text}\n\n")
    print(f"Saved note '{title}' to {notes.name}")

elif req["tool"] == "note_list":
    if not notes.exists():
        print("No notes yet.")
        sys.exit(0)
    chunks = [c for c in notes.read_text(encoding="utf-8").split("## ") if c.strip()]
    last = int(req["params"].get("last", 10))
    shown = chunks[-last:]
    print(f"{len(shown)} of {len(chunks)} note(s):\n")
    print("\n".join("## " + c.rstrip() + "\n" for c in shown))

else:
    # Reporting a failure: the AI sees this message as an error.
    print(json.dumps({"ok": False, "error": f"unknown tool {req['tool']}"}))
