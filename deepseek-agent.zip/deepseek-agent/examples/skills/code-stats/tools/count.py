"""code-stats. Protocol: arguments on the command line (input: args).
argv: project_dir path [ext]   (ext is left out entirely when the AI did not give one)"""
import os
import sys
from collections import Counter

SKIP = {".git", "node_modules", "__pycache__", ".venv", "venv", "dist", "build"}
project, rel = sys.argv[1], sys.argv[2]
only = sys.argv[3] if len(sys.argv) > 3 else None

root = os.path.realpath(os.path.join(project, rel))
if os.path.commonpath([root, os.path.realpath(project)]) != os.path.realpath(project):
    print("path is outside the project")   # tools must guard their own paths
    sys.exit(1)

files, lines = Counter(), Counter()
for dirpath, dirnames, filenames in os.walk(root):
    dirnames[:] = [d for d in dirnames if d not in SKIP]
    for fn in filenames:
        ext = os.path.splitext(fn)[1].lower() or "(none)"
        if only and ext != only.lower():
            continue
        try:
            with open(os.path.join(dirpath, fn), "rb") as f:
                data = f.read()
        except OSError:
            continue
        if b"\0" in data[:2048]:
            continue
        files[ext] += 1
        lines[ext] += data.count(b"\n")

if not files:
    print("No matching files.")
else:
    print(f"{'ext':<10}{'files':>7}{'lines':>9}")
    for ext, n in lines.most_common():
        print(f"{ext:<10}{files[ext]:>7}{n:>9}")
    print(f"{'total':<10}{sum(files.values()):>7}{sum(lines.values()):>9}")
