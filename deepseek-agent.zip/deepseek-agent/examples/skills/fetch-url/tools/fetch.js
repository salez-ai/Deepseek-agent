// fetch-url tool. Protocol: JSON on stdin, text on stdout (Node.js 18+).
let raw = '';
process.stdin.on('data', (d) => (raw += d));
process.stdin.on('end', async () => {
  const { params } = JSON.parse(raw);
  const fail = (error) => { console.log(JSON.stringify({ ok: false, error })); process.exit(0); };

  let url;
  try { url = new URL(params.url); } catch { return fail('That is not a valid URL.'); }
  if (!['http:', 'https:'].includes(url.protocol)) return fail('Only http and https URLs are allowed.');

  try {
    const res = await fetch(url, { signal: AbortSignal.timeout(20000), headers: { 'user-agent': 'deepseek-agent-skill/1.0' } });
    let text = await res.text();
    if ((res.headers.get('content-type') || '').includes('html')) {
      text = text.replace(/<(script|style)[\s\S]*?<\/\1>/gi, ' ').replace(/<[^>]+>/g, ' ').replace(/&nbsp;/g, ' ').replace(/\s+/g, ' ').trim();
    }
    const max = params.max_chars;
    const cut = text.length > max ? text.slice(0, max) + `\n[cut: ${text.length - max} more characters]` : text;
    if (!res.ok) return fail(`HTTP ${res.status}\n${cut}`);
    console.log(`HTTP ${res.status} ${url.href}\n\n${cut}`);
  } catch (e) {
    fail(`Request failed: ${e.message}`);
  }
});
