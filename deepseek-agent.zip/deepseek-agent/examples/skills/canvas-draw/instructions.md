# Drawing images

You can make images by drawing shapes. You cannot see the result, but the user can: it appears in the chat. Plan the picture in coordinates first, then write ONE script.

## Workflow
1. Choose a canvas size and list the parts from back to front (sky, ground, objects, details).
2. Call `draw` with a short lowercase `drawing` name and the script as the body.
3. The user looks at it and tells you what to change. Do not claim to know how it looks.
4. To change something, call `draw` with `mode: append` and give the shape the same `id=` (it is replaced in place), or use `draw_remove`. `draw_list` shows every id with the area it covers. Prefer editing over starting again.
5. Use `draw_svg` only when the script cannot express what you need.

## Script syntax
One command per line. A line starting with `#` is a comment. Numbers may be separated by spaces or written as x,y pairs (`rect 10 20 100 50` = `rect 10,20 100,50`). x goes right, y goes down, (0,0) is the top-left corner. Options are `key=value`; put values containing spaces in double quotes.

```
canvas W H [bg=COLOR]                  first line; default 800 600 bg=white (16..4096)
rect X Y W H [radius=R]
circle CX CY R
ellipse CX CY RX RY
line X1 Y1 X2 Y2
polygon X,Y X,Y X,Y ...                3 or more points, closed
polyline X,Y X,Y ...                   open
path d="M 10 10 C 40 0 60 0 90 10 Z"  commands M L H V C S Q T A Z
text X Y "words" [size=24 font=Arial weight=bold anchor=middle italic=true]
lineargradient ID X1 Y1 X2 Y2 0:#ffffff 1:#000000
radialgradient ID CX CY R 0:#ffffff 1:#000000
group [translate=X,Y] [rotate=DEG@X,Y] [scale=S] [opacity=O]   ...shapes...   end
```

Options for shapes: `fill=` `stroke=` `sw=` (stroke width) `opacity=` `fo=` (fill opacity) `so=` (stroke opacity) `dash="8 4"` `cap=round` `join=round` `rotate=DEG` (about the shape's centre, or `rotate=DEG@X,Y`) `blur=N` `id=NAME`.
- Colours: `#rrggbb`, a CSS name (`tomato`), `none`, or `url(#gradientid)`. Write rgb()/hsl() in quotes.
- Gradient coordinates are fractions (0 to 1) of the shape they fill: `0 0 0 1` is top to bottom. Define a gradient before the shapes that use it.
- Defaults: rect/circle/ellipse/polygon/text fill #000000 with no stroke. line/polyline/path have no fill and a black stroke of width 1; a path with `fill=` and no `stroke=` gets no stroke.
- Text is placed by its baseline. Use `anchor=middle` with the centre x to centre it. Keep text short.
- Shapes are drawn in order, later ones on top. Groups move, rotate or scale many shapes at once; nest at most 4 deep.
- Give shapes you may change later an `id=`. Others get s1, s2...

## Example
```tool
name: draw
drawing: sunset
=====BODY=====
canvas 800 500 bg=#0b1d3a
lineargradient sky 0 0 0 1 0:#1b2a6b 0.6:#e0526b 1:#ffb347
rect 0 0 800 340 fill=url(#sky) id=sky_rect
circle 560 300 70 fill=#fff1b8 id=sun blur=2
rect 0 340 800 160 fill=#16324f id=sea
polygon 0,340 120,250 240,340 fill=#0d1b2a id=hill_left
group translate=90,390 id=boat
  polygon 0,0 120,0 100,30 20,30 fill=#2b1d12
  line 60 0 60 -90 stroke=#2b1d12 sw=3
  polygon 60,-90 60,-10 110,-10 fill=#f6e7c1
end
text 400 460 "Evening" size=28 anchor=middle fill=#f6e7c1 weight=bold
=====END=====
```

## Tips
- Make the picture clear and bold: a few well-chosen shapes beat hundreds of tiny ones. Keep a small palette (4 to 6 colours) and use gradients for skies, light and depth.
- For smooth organic outlines use `path` with C or Q curves. Build repeated parts (windows, trees) once in a `group` and copy it with different `translate=`.
- Read the "Warnings" in the tool result: they flag shapes (also inside groups) that fall mostly outside the canvas, have zero size or are invisible. Positions are your only way to "see", so check them with `draw_list` (it shows the area each shape covers).
- If the script has errors, nothing is saved. Fix every listed line and send the whole script again.
- Icons: use a small canvas such as 256 256. Diagrams: rect + text + line + polygon (arrow heads).
- If the user wants a PNG, tell them to click Open under the image in the chat and press Download PNG.
