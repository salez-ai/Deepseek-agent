"""
Drawing script -> model -> SVG.

The AI writes a small line-based script (see ../instructions.md). This module parses it
strictly, keeps the result as a JSON-able model (so drawings can be extended, edited by id
and listed later), and renders the model to SVG with our own serializer. Nothing the AI
writes is copied into the SVG without validation, so a script cannot inject markup.
"""
import copy
import math
import re
from xml.sax.saxutils import escape, quoteattr


class DrawError(Exception):
    """One or more problems in the script. `.errors` is a list of 'line N: ...' strings."""

    def __init__(self, errors):
        self.errors = errors if isinstance(errors, list) else [errors]
        super().__init__("\n".join(self.errors))


MAX_COORD = 100000
MAX_SHAPES = 2000
MAX_DEPTH = 4
MIN_CANVAS, MAX_CANVAS = 16, 4096
MAX_TEXT = 500
MAX_PATH = 20000
MAX_ERRORS = 10

NAMED = set("""aliceblue antiquewhite aqua aquamarine azure beige bisque black blanchedalmond blue blueviolet brown
burlywood cadetblue chartreuse chocolate coral cornflowerblue cornsilk crimson cyan darkblue darkcyan darkgoldenrod
darkgray darkgreen darkgrey darkkhaki darkmagenta darkolivegreen darkorange darkorchid darkred darksalmon darkseagreen
darkslateblue darkslategray darkslategrey darkturquoise darkviolet deeppink deepskyblue dimgray dimgrey dodgerblue
firebrick floralwhite forestgreen fuchsia gainsboro ghostwhite gold goldenrod gray green greenyellow grey honeydew
hotpink indianred indigo ivory khaki lavender lavenderblush lawngreen lemonchiffon lightblue lightcoral lightcyan
lightgoldenrodyellow lightgray lightgreen lightgrey lightpink lightsalmon lightseagreen lightskyblue lightslategray
lightslategrey lightsteelblue lightyellow lime limegreen linen magenta maroon mediumaquamarine mediumblue mediumorchid
mediumpurple mediumseagreen mediumslateblue mediumspringgreen mediumturquoise mediumvioletred midnightblue mintcream
mistyrose moccasin navajowhite navy oldlace olive olivedrab orange orangered orchid palegoldenrod palegreen
paleturquoise palevioletred papayawhip peachpuff peru pink plum powderblue purple rebeccapurple red rosybrown royalblue
saddlebrown salmon sandybrown seagreen seashell sienna silver skyblue slateblue slategray slategrey snow springgreen
steelblue tan teal thistle tomato turquoise violet wheat white whitesmoke yellow yellowgreen""".split())
HEX_RE = re.compile(r"^#(?:[0-9a-fA-F]{3,4}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$")
FUNC_RE = re.compile(r"^(?:rgb|rgba|hsl|hsla)\(\s*[-+0-9.]+%?\s*(?:,\s*[-+0-9.]+%?\s*){2,3}\)$")
URL_RE = re.compile(r"^url\(#([A-Za-z][A-Za-z0-9_-]{0,30})\)$")
ID_RE = re.compile(r"^[A-Za-z][A-Za-z0-9_-]{0,30}$")
FONT_RE = re.compile(r"^[A-Za-z0-9 ,'\-]{1,80}$")
PATH_RE = re.compile(r"^[MmLlHhVvCcSsQqTtAaZz0-9eE+\-., \t\r\n]+$")

PAINT_OPTS = {"fill", "stroke", "sw", "fo", "so", "dash", "cap", "join"}
COMMON_OPTS = {"id", "opacity", "rotate", "blur"}
OPTIONS = {
    "rect": COMMON_OPTS | PAINT_OPTS | {"rx", "ry", "radius"},
    "circle": COMMON_OPTS | PAINT_OPTS,
    "ellipse": COMMON_OPTS | PAINT_OPTS,
    "line": COMMON_OPTS | PAINT_OPTS,
    "polygon": COMMON_OPTS | PAINT_OPTS,
    "polyline": COMMON_OPTS | PAINT_OPTS,
    "path": COMMON_OPTS | PAINT_OPTS | {"d"},
    "text": COMMON_OPTS | {"fill", "stroke", "sw", "fo", "so", "size", "font", "weight", "anchor", "italic"},
    "group": {"id", "opacity", "translate", "scale", "rotate", "blur"},
    "canvas": {"bg"},
}
SHAPES = ("rect", "circle", "ellipse", "line", "polygon", "polyline", "path", "text")


# ---------------------------------------------------------------------------
# tokenizer
# ---------------------------------------------------------------------------
def tokenize(line, n):
    """Return [(key, value, quoted)]. A token is `word`, `"quoted text"`, `key=value` or `key="quoted"`."""
    toks, i, size = [], 0, len(line)
    while i < size:
        if line[i].isspace():
            i += 1
            continue
        if line[i] == "#":                       # comment (colours are always written key=#hex)
            break
        key, buf, quoted = None, [], False
        while i < size and not line[i].isspace():
            ch = line[i]
            if ch == '"':
                quoted = True
                i += 1
                while i < size and line[i] != '"':
                    if line[i] == "\\" and i + 1 < size:
                        buf.append(line[i + 1])
                        i += 2
                    else:
                        buf.append(line[i])
                        i += 1
                if i >= size:
                    raise DrawError(f"line {n}: a double quote is never closed")
                i += 1
            else:
                if ch == "=" and key is None and not quoted and buf and re.fullmatch(r"[a-z_]+", "".join(buf)):
                    key, buf = "".join(buf), []
                else:
                    buf.append(ch)
                i += 1
        toks.append((key, "".join(buf), quoted))
    return toks


# ---------------------------------------------------------------------------
# value parsers (each raises ValueError with a short reason)
# ---------------------------------------------------------------------------
def num(text, lo=-MAX_COORD, hi=MAX_COORD):
    try:
        v = float(text)
    except (TypeError, ValueError):
        raise ValueError(f"'{text}' is not a number")
    if not math.isfinite(v) or v < lo or v > hi:
        raise ValueError(f"{text} is out of range ({lo} to {hi})")
    return int(v) if v == int(v) else round(v, 3)


def fmt(v):
    if isinstance(v, float):
        s = f"{v:.3f}".rstrip("0").rstrip(".")
        return s or "0"
    return str(v)


def color(text):
    t = text.strip()
    if t.lower() in ("none", "transparent"):
        return "none"
    if HEX_RE.match(t):
        return t.lower()
    if t.lower() in NAMED:
        return t.lower()
    if FUNC_RE.match(t):
        return t.replace(" ", "")
    if URL_RE.match(t):
        return t
    raise ValueError(f"'{text}' is not a colour (use #rrggbb, a CSS colour name, none, or url(#gradient-id))")


def pair(text):
    m = re.fullmatch(r"([^,]+),([^,]+)", text)
    if not m:
        raise ValueError(f"'{text}' should look like x,y")
    return num(m.group(1)), num(m.group(2))


def parse_rotate(text):
    m = re.fullmatch(r"([^@]+)(?:@([^@]+))?", text)
    deg = num(m.group(1), -3600, 3600)
    center = pair(m.group(2)) if m.group(2) else None
    return {"deg": deg, "center": center}


def parse_option(cmd, key, val):
    """Validate one key=value option and return its normalised value."""
    if key in ("fill", "stroke", "bg"):
        return color(val)
    if key in ("opacity", "fo", "so"):
        return num(val, 0, 1)
    if key == "sw":
        return num(val, 0, 1000)
    if key in ("rx", "ry", "radius"):
        return num(val, 0, MAX_COORD)
    if key == "rotate":
        return parse_rotate(val)
    if key == "blur":
        return num(val, 0, 200)
    if key == "dash":
        parts = val.replace(",", " ").split()
        if not parts or len(parts) > 8:
            raise ValueError("dash needs 1 to 8 numbers, e.g. dash=\"8 4\"")
        return " ".join(fmt(num(p, 0, 10000)) for p in parts)
    if key == "cap":
        if val not in ("butt", "round", "square"):
            raise ValueError("cap must be butt, round or square")
        return val
    if key == "join":
        if val not in ("miter", "round", "bevel"):
            raise ValueError("join must be miter, round or bevel")
        return val
    if key == "id":
        if not ID_RE.match(val):
            raise ValueError("id must start with a letter and use only letters, digits, - and _ (max 31)")
        return val
    if key == "d":
        if len(val) > MAX_PATH or not PATH_RE.match(val):
            raise ValueError("d must be an SVG path made of M L H V C S Q T A Z commands and numbers")
        return " ".join(val.split())
    if key == "size":
        return num(val, 1, 2000)
    if key == "font":
        if not FONT_RE.match(val):
            raise ValueError("font may contain letters, digits, spaces, commas, - and ' only")
        return val
    if key == "weight":
        if val not in ("normal", "bold") and not re.fullmatch(r"[1-9]00", val):
            raise ValueError("weight must be normal, bold or 100-900")
        return val
    if key == "anchor":
        if val not in ("start", "middle", "end"):
            raise ValueError("anchor must be start, middle or end")
        return val
    if key == "italic":
        if val not in ("true", "false", "yes", "no"):
            raise ValueError("italic must be true or false")
        return val in ("true", "yes")
    if key == "translate":
        return pair(val)
    if key == "scale":
        if "," in val:
            return pair(val)
        s = num(val, -1000, 1000)
        return (s, s)
    raise ValueError("unsupported option")


# ---------------------------------------------------------------------------
# the model
# ---------------------------------------------------------------------------
def new_model():
    return {"width": 800, "height": 600, "bg": "white", "defs": [], "nodes": [], "next_id": 1}


def walk(nodes, depth=0):
    for n in nodes:
        yield n, depth
        if n["type"] == "group":
            yield from walk(n["children"], depth + 1)


def count_shapes(model):
    return sum(1 for n, _ in walk(model["nodes"]) if n["type"] != "group")


def all_ids(model):
    return {n["id"] for n, _ in walk(model["nodes"])} | {d["id"] for d in model["defs"]}


def find_parent_list(nodes, node_id):
    """Return (list, index) holding the node with this id, searching groups too."""
    for i, n in enumerate(nodes):
        if n["id"] == node_id:
            return nodes, i
        if n["type"] == "group":
            hit = find_parent_list(n["children"], node_id)
            if hit:
                return hit
    return None


def remove_ids(model, ids):
    """All-or-nothing: if any id does not exist, nothing is changed. Returns (removed, missing)."""
    def exists(i):
        return bool(find_parent_list(model["nodes"], i)) or any(d["id"] == i for d in model["defs"])

    missing = [i for i in ids if not exists(i)]
    if missing:
        return [], missing
    removed = []
    for i in ids:
        hit = find_parent_list(model["nodes"], i)       # may already be gone if a parent group was removed
        if hit:
            lst, idx = hit
            removed.append(lst.pop(idx)["id"])
        else:
            defs = [d for d in model["defs"] if d["id"] == i]
            if defs:
                model["defs"].remove(defs[0])
                removed.append(i)
    return removed, []


# ---------------------------------------------------------------------------
# parsing a script
# ---------------------------------------------------------------------------
class Parser:
    def __init__(self, model, append):
        self.model = copy.deepcopy(model)
        self.append = append
        self.errors, self.warnings = [], []
        self.stack = [self.model["nodes"]]   # lists we are currently adding to
        self.open_groups = []                # (line number, node)
        self.seen_ids = set()                # ids defined in THIS script
        self.refs = []                       # (line, gradient id) used before/after definition
        self.shape_seen = False
        self.replaced = []

    def err(self, n, msg):
        if len(self.errors) < MAX_ERRORS:
            self.errors.append(f"line {n}: {msg}")

    # -- helpers -----------------------------------------------------------
    def assign_id(self, n, node, requested):
        if requested:
            if requested in self.seen_ids:
                self.err(n, f"id '{requested}' is used twice in this script")
                return
            self.seen_ids.add(requested)
            node["id"] = requested
        else:
            while True:
                cand = f"s{self.model['next_id']}"
                self.model["next_id"] += 1
                if cand not in self.seen_ids and cand not in all_ids(self.model):
                    break
            self.seen_ids.add(cand)
            node["id"] = cand

    def add(self, n, node):
        """Append a node to the current group, or replace an existing node with the same id."""
        if count_shapes(self.model) + (0 if node["type"] == "group" else 1) > MAX_SHAPES:
            self.err(n, f"too many shapes (limit {MAX_SHAPES})")
            return
        requested = node["id"]
        if requested and self.append:
            hit = find_parent_list(self.model["nodes"], requested)
            if hit:
                lst, idx = hit
                lst[idx] = node
                self.replaced.append(requested)
                if node["type"] == "group":
                    self.stack.append(node["children"])
                return
            if requested in {d["id"] for d in self.model["defs"]}:
                self.err(n, f"id '{requested}' is already used by a gradient")
                return
        self.stack[-1].append(node)
        if node["type"] == "group":
            self.stack.append(node["children"])

    def options(self, n, cmd, toks):
        """Split keyed tokens into validated options; return dict. Positional tokens are not allowed here."""
        out = {}
        allowed = OPTIONS[cmd]
        for key, val, _ in toks:
            if key is None:
                self.err(n, f"unexpected '{val}' after the {cmd} values. Options are written key=value (valid: {', '.join(sorted(allowed))})")
                continue
            if key not in allowed:
                self.err(n, f"{cmd} has no option '{key}'. Valid options: {', '.join(sorted(allowed))}")
                continue
            if key in out:
                self.err(n, f"option '{key}' is given twice")
                continue
            try:
                out[key] = parse_option(cmd, key, val)
            except ValueError as e:
                self.err(n, f"{cmd} {key}: {e}")
                continue
            if key in ("fill", "stroke") and isinstance(out[key], str):
                m = URL_RE.match(out[key])
                if m:
                    self.refs.append((n, m.group(1)))
        return out

    def split_positional(self, toks):
        i = 0
        while i < len(toks) and toks[i][0] is None:
            i += 1
        return toks[:i], toks[i:]

    def numbers(self, n, cmd, pos, count, names):
        # accept "10 20 30 40" as well as "10,20 30,40" (models mix both styles)
        flat = [p for _, v, _ in pos for p in (v.split(",") if "," in v else [v])]
        if len(flat) != count:
            self.err(n, f"{cmd} needs {names} ({count} numbers), got {len(flat)}")
            return None
        vals = []
        for v in flat:
            try:
                vals.append(num(v))
            except ValueError as e:
                self.err(n, f"{cmd}: {e}")
                return None
        return vals

    def points(self, n, cmd, pos, minimum):
        flat = []
        try:
            for _, v, _ in pos:
                if "," in v:
                    flat.extend(pair(v))
                else:
                    flat.append(num(v))
        except ValueError as e:
            self.err(n, f"{cmd}: {e}")
            return None
        if len(flat) % 2:
            self.err(n, f"{cmd} points must come in x,y pairs (got an odd count of numbers)")
            return None
        if len(flat) // 2 < minimum:
            self.err(n, f"{cmd} needs at least {minimum} points, got {len(flat) // 2}")
            return None
        if len(flat) // 2 > 1000:
            self.err(n, f"{cmd} has too many points (limit 1000)")
            return None
        return [[flat[i], flat[i + 1]] for i in range(0, len(flat), 2)]

    def stops(self, n, cmd, pos):
        stops = []
        for _, v, _ in pos:
            m = re.fullmatch(r"([^:]+):(.+)", v)
            if not m:
                self.err(n, f"{cmd} stops look like offset:colour, e.g. 0:#ffffff 1:#000000 (got '{v}')")
                return None
            try:
                off = m.group(1)
                off = num(off[:-1], 0, 100) / 100 if off.endswith("%") else num(off, 0, 1)
                col = color(m.group(2))
            except ValueError as e:
                self.err(n, f"{cmd} stop '{v}': {e}")
                return None
            stops.append([off, col])
        if len(stops) < 2:
            self.err(n, f"{cmd} needs at least 2 stops (offset:colour)")
            return None
        if len(stops) > 12:
            self.err(n, f"{cmd} has too many stops (limit 12)")
            return None
        return stops

    # -- one line ----------------------------------------------------------
    def line(self, n, text):
        try:
            toks = tokenize(text, n)
        except DrawError as e:
            self.err(n, e.errors[0].split(": ", 1)[1])
            return
        if not toks:
            return
        if toks[0][0] is not None or toks[0][2]:
            self.err(n, "a line must start with a command (canvas, rect, circle, ellipse, line, polygon, polyline, path, text, lineargradient, radialgradient, group, end)")
            return
        cmd, rest = toks[0][1].lower(), toks[1:]

        if cmd == "end":
            if rest:
                self.err(n, "end takes no values")
            elif not self.open_groups:
                self.err(n, "end without a matching group")
            else:
                self.open_groups.pop()
                self.stack.pop()
            return

        if cmd == "canvas":
            pos, kv = self.split_positional(rest)
            vals = self.numbers(n, cmd, pos, 2, "width height")
            opts = self.options(n, cmd, kv)
            if self.shape_seen:
                self.err(n, "canvas must come before the first shape")
                return
            if vals:
                w, h = vals
                if not (MIN_CANVAS <= w <= MAX_CANVAS and MIN_CANVAS <= h <= MAX_CANVAS):
                    self.err(n, f"canvas size must be {MIN_CANVAS} to {MAX_CANVAS} in both directions")
                else:
                    self.model["width"], self.model["height"] = int(w), int(h)
            if "bg" in opts:
                self.model["bg"] = opts["bg"]
                m = URL_RE.match(str(opts["bg"]))
                if m:
                    self.refs.append((n, m.group(1)))
            return

        if cmd in ("lineargradient", "radialgradient"):
            pos, kv = self.split_positional(rest)
            if kv:
                self.err(n, f"{cmd} takes no key=value options")
            need = 5 if cmd == "lineargradient" else 4
            if len(pos) < need + 2:
                names = "id x1 y1 x2 y2" if cmd == "lineargradient" else "id cx cy r"
                self.err(n, f"{cmd} needs {names} and at least 2 stops (offset:colour)")
                return
            gid = pos[0][1]
            if not ID_RE.match(gid):
                self.err(n, f"gradient id '{gid}' must start with a letter and use letters, digits, - and _")
                return
            if gid in self.seen_ids:
                self.err(n, f"id '{gid}' is used twice in this script")
                return
            vals = self.numbers(n, cmd, pos[1:need], need - 1, "coordinates")
            stops = self.stops(n, cmd, pos[need:])
            if vals is None or stops is None:
                return
            if gid in {x["id"] for x, _ in walk(self.model["nodes"])}:
                self.err(n, f"id '{gid}' is already used by a shape")
                return
            self.seen_ids.add(gid)
            self.model["defs"] = [d for d in self.model["defs"] if d["id"] != gid]
            self.model["defs"].append({"id": gid, "kind": "linear" if cmd == "lineargradient" else "radial",
                                       "coords": vals, "stops": stops})
            return

        if cmd not in SHAPES and cmd != "group":
            self.err(n, f"unknown command '{cmd}'. Commands: canvas, rect, circle, ellipse, line, polygon, polyline, path, text, lineargradient, radialgradient, group, end")
            return

        pos, kv = self.split_positional(rest)
        node = {"type": cmd, "id": None, "a": {}}
        before = len(self.errors)

        if cmd == "group":
            if pos:
                self.err(n, "group takes only key=value options (translate, scale, rotate, opacity, blur, id)")
        elif cmd == "rect":
            v = self.numbers(n, cmd, pos, 4, "x y width height")
            if v:
                if v[2] < 0 or v[3] < 0:
                    self.err(n, "rect width and height must not be negative")
                node["a"].update(x=v[0], y=v[1], w=v[2], h=v[3])
        elif cmd == "circle":
            v = self.numbers(n, cmd, pos, 3, "cx cy r")
            if v:
                if v[2] < 0:
                    self.err(n, "circle r must not be negative")
                node["a"].update(cx=v[0], cy=v[1], r=v[2])
        elif cmd == "ellipse":
            v = self.numbers(n, cmd, pos, 4, "cx cy rx ry")
            if v:
                if v[2] < 0 or v[3] < 0:
                    self.err(n, "ellipse radii must not be negative")
                node["a"].update(cx=v[0], cy=v[1], rx=v[2], ry=v[3])
        elif cmd == "line":
            v = self.numbers(n, cmd, pos, 4, "x1 y1 x2 y2")
            if v:
                node["a"].update(x1=v[0], y1=v[1], x2=v[2], y2=v[3])
        elif cmd in ("polygon", "polyline"):
            p = self.points(n, cmd, pos, 3 if cmd == "polygon" else 2)
            if p:
                node["a"]["points"] = p
        elif cmd == "path":
            if pos:
                self.err(n, 'path takes its shape as d="M 10 10 L 90 10 ..." (in double quotes)')
        elif cmd == "text":
            if len(pos) != 3:
                self.err(n, 'text needs x y "the text in double quotes"')
            else:
                try:
                    x, y = num(pos[0][1]), num(pos[1][1])
                except ValueError as e:
                    self.err(n, f"text: {e}")
                    x = y = None
                s = pos[2][1]
                if not s.strip():
                    self.err(n, "text is empty")
                elif len(s) > MAX_TEXT:
                    self.err(n, f"text is longer than {MAX_TEXT} characters")
                elif any(ord(c) < 32 for c in s):
                    self.err(n, "text must not contain control characters")
                elif x is not None:
                    node["a"].update(x=x, y=y, text=s)

        opts = self.options(n, cmd, kv)
        if cmd == "path" and "d" not in opts and len(self.errors) == before:
            self.err(n, 'path needs d="..."')
        if len(self.errors) > before:
            return
        node["id"] = opts.pop("id", None)
        node["a"].update(opts)
        if cmd == "group":
            if len(self.open_groups) >= MAX_DEPTH:
                self.err(n, f"groups can be nested at most {MAX_DEPTH} deep")
                return
            node["children"] = []
        else:
            self.shape_seen = True
        self.assign_id(n, node, node["id"])
        if len(self.errors) > before:
            return
        self.add(n, node)
        if cmd == "group" and len(self.errors) == before:
            self.open_groups.append((n, node))

    # -- whole script ------------------------------------------------------
    def run(self, script):
        lines = script.replace("\r\n", "\n").replace("\r", "\n").split("\n")
        if len(lines) > 5000:
            raise DrawError("the script has more than 5000 lines; split it into several draw calls with mode=append")
        for n, text in enumerate(lines, 1):
            self.line(n, text)
        for n, node in self.open_groups:
            self.err(n, "this group is never closed with 'end'")
        known = {d["id"] for d in self.model["defs"]}
        for n, gid in self.refs:
            if gid not in known:
                self.err(n, f"gradient '{gid}' is not defined. Define it with lineargradient/radialgradient")
        if self.errors:
            raise DrawError(self.errors)
        self.warnings += lint(self.model)
        return self.model


def apply_script(model, script, append):
    p = Parser(model, append)
    new = p.run(script)
    return new, p.warnings, p.replaced


# ---------------------------------------------------------------------------
# bounding boxes and lint (the AI cannot see the picture, so we point out likely mistakes)
# ---------------------------------------------------------------------------
def bbox(node):
    a, t = node["a"], node["type"]
    if t == "rect":
        return a["x"], a["y"], a["x"] + a["w"], a["y"] + a["h"]
    if t == "circle":
        return a["cx"] - a["r"], a["cy"] - a["r"], a["cx"] + a["r"], a["cy"] + a["r"]
    if t == "ellipse":
        return a["cx"] - a["rx"], a["cy"] - a["ry"], a["cx"] + a["rx"], a["cy"] + a["ry"]
    if t == "line":
        return min(a["x1"], a["x2"]), min(a["y1"], a["y2"]), max(a["x1"], a["x2"]), max(a["y1"], a["y2"])
    if t in ("polygon", "polyline"):
        xs, ys = [p[0] for p in a["points"]], [p[1] for p in a["points"]]
        return min(xs), min(ys), max(xs), max(ys)
    return None


# 2D affine matrices as [a, b, c, d, e, f]:  x' = a*x + c*y + e,  y' = b*x + d*y + f
def m_mul(p, q):
    return [p[0] * q[0] + p[2] * q[1], p[1] * q[0] + p[3] * q[1],
            p[0] * q[2] + p[2] * q[3], p[1] * q[2] + p[3] * q[3],
            p[0] * q[4] + p[2] * q[5] + p[4], p[1] * q[4] + p[3] * q[5] + p[5]]


def m_apply(m, x, y):
    return m[0] * x + m[2] * y + m[4], m[1] * x + m[3] * y + m[5]


def m_rotate(deg, cx=0, cy=0):
    r = math.radians(deg)
    c, s = math.cos(r), math.sin(r)
    return m_mul(m_mul([1, 0, 0, 1, cx, cy], [c, s, -s, c, 0, 0]), [1, 0, 0, 1, -cx, -cy])


IDENTITY = [1, 0, 0, 1, 0, 0]


def node_matrix(node):
    """The node's own transform, in the same order the SVG output uses: translate, rotate, scale."""
    a, m = node["a"], IDENTITY
    if "translate" in a:
        m = m_mul(m, [1, 0, 0, 1, a["translate"][0], a["translate"][1]])
    if "rotate" in a:
        c = a["rotate"]["center"] or (default_center(node) if node["type"] != "group" else None) or (0, 0)
        m = m_mul(m, m_rotate(a["rotate"]["deg"], c[0], c[1]))
    if "scale" in a:
        m = m_mul(m, [a["scale"][0], 0, 0, a["scale"][1], 0, 0])
    return m


def box_of_points(m, pts):
    xs, ys = zip(*(m_apply(m, x, y) for x, y in pts))
    return min(xs), min(ys), max(xs), max(ys)


def corners(b):
    return [(b[0], b[1]), (b[2], b[1]), (b[2], b[3]), (b[0], b[3])]


def box_in_parent(node):
    """Bounding box of a node in its PARENT's coordinates (None if unknown, e.g. path or text)."""
    if node["type"] == "group":
        boxes = [b for b in (box_in_parent(c) for c in node["children"]) if b]
        if not boxes:
            return None
        inner = (min(b[0] for b in boxes), min(b[1] for b in boxes), max(b[2] for b in boxes), max(b[3] for b in boxes))
    else:
        inner = bbox(node)
        if not inner:
            return None
    return box_of_points(node_matrix(node), corners(inner))


def visible_fraction(box, W, H):
    area = (box[2] - box[0]) * (box[3] - box[1])
    if area <= 0:
        return 1.0
    ix = max(0.0, min(box[2], W) - max(box[0], 0))
    iy = max(0.0, min(box[3], H) - max(box[1], 0))
    return (ix * iy) / area


def lint(model):
    """The AI cannot see the picture, so point out likely mistakes in plain words."""
    W, H = model["width"], model["height"]
    out = []

    def visit(nodes, acc, check_outside):
        for n in nodes:
            a, t = n["a"], n["type"]
            canvas_box = None
            local = box_in_parent(n)
            if local:
                canvas_box = box_of_points(acc, corners(local))
            flagged = False
            if check_outside and canvas_box:
                frac = visible_fraction(canvas_box, W, H)
                what = f"group {n['id']}" if t == "group" else f"{n['id']} ({t})"
                if frac == 0:
                    out.append(f"{what} is completely outside the {W}x{H} canvas (it covers {fmt(round(canvas_box[0]))},{fmt(round(canvas_box[1]))} to {fmt(round(canvas_box[2]))},{fmt(round(canvas_box[3]))})")
                    flagged = True
                elif frac < 0.75:
                    out.append(f"{what} is only about {int(frac * 100)}% inside the {W}x{H} canvas (it covers {fmt(round(canvas_box[0]))},{fmt(round(canvas_box[1]))} to {fmt(round(canvas_box[2]))},{fmt(round(canvas_box[3]))}). Ignore this if it is meant to bleed off the edge")
                    flagged = True
            if t == "group":
                visit(n["children"], m_mul(acc, node_matrix(n)), check_outside and not flagged)
                continue
            box = bbox(n)
            if t in ("rect", "circle", "ellipse") and box and box[0] == box[2] and box[1] == box[3]:
                out.append(f"{n['id']} ({t}) has zero size and will not be visible")
            if t in ("rect", "circle", "ellipse", "polygon", "text"):
                if a.get("fill", "#000000") == "none" and a.get("stroke", "none") == "none":
                    out.append(f"{n['id']} ({t}) has fill=none and no stroke, so it is invisible")
            if a.get("opacity") == 0:
                out.append(f"{n['id']} ({t}) has opacity=0 and is invisible")

    visit(model["nodes"], IDENTITY, True)
    return out[:15]


def describe(node):
    a, t = node["a"], node["type"]
    bits = []
    for k in ("x", "y", "w", "h", "cx", "cy", "r", "rx", "ry", "x1", "y1", "x2", "y2"):
        if k in a and t in ("rect", "circle", "ellipse", "line", "text"):
            bits.append(f"{k}={fmt(a[k])}")
    if t in ("polygon", "polyline"):
        bits.append(f"{len(a['points'])} points")
    if t == "text":
        bits.append(f'"{a["text"][:30]}"')
    if t == "path":
        bits.append(f"d={a['d'][:30]}{'...' if len(a['d']) > 30 else ''}")
    if t == "group":
        bits.append(f"{sum(1 for _ in walk(node['children']))} items")
    for k in ("fill", "stroke"):
        if k in a:
            bits.append(f"{k}={a[k]}")
    box = bbox(node)
    where = f"  [covers {fmt(box[0])},{fmt(box[1])} to {fmt(box[2])},{fmt(box[3])}]" if box else ""
    return f"{node['id']} {t} " + " ".join(bits) + where


# ---------------------------------------------------------------------------
# rendering
# ---------------------------------------------------------------------------
def attr(name, value):
    return f" {name}={quoteattr(str(value))}"


def transform_of(node, default_center):
    a, parts = node["a"], []
    if "translate" in a:
        parts.append(f"translate({fmt(a['translate'][0])} {fmt(a['translate'][1])})")
    if "rotate" in a:
        deg = a["rotate"]["deg"]
        c = a["rotate"]["center"] or default_center
        parts.append(f"rotate({fmt(deg)} {fmt(c[0])} {fmt(c[1])})" if c else f"rotate({fmt(deg)})")
    if "scale" in a:
        parts.append(f"scale({fmt(a['scale'][0])} {fmt(a['scale'][1])})")
    return " ".join(parts)


def default_center(node):
    t, a = node["type"], node["a"]
    if t == "text":
        return (a["x"], a["y"])
    box = bbox(node)
    if box:
        return ((box[0] + box[2]) / 2, (box[1] + box[3]) / 2)
    return None


def common_attrs(node, blurs):
    a, s = node["a"], attr("id", node["id"])
    if "opacity" in a:
        s += attr("opacity", fmt(a["opacity"]))
    tf = transform_of(node, default_center(node) if node["type"] != "group" else None)
    if tf:
        s += attr("transform", tf)
    if a.get("blur"):
        key = fmt(a["blur"]).replace(".", "_")
        blurs.add(key)
        s += attr("filter", f"url(#dsa-blur-{key})")
    return s


def paint_attrs(node, closed):
    a, s = node["a"], ""
    if closed:
        s += attr("fill", a.get("fill", "#000000"))
        stroke = a.get("stroke", "none")
    else:   # line / polyline / path: stroked by default
        if node["type"] == "path" and "fill" in a and "stroke" not in a:
            stroke = "none"
        else:
            stroke = a.get("stroke", "#000000")
        s += attr("fill", a.get("fill", "none"))
    s += attr("stroke", stroke)
    if stroke != "none":
        s += attr("stroke-width", fmt(a.get("sw", 1)))
    if "fo" in a:
        s += attr("fill-opacity", fmt(a["fo"]))
    if "so" in a:
        s += attr("stroke-opacity", fmt(a["so"]))
    if "dash" in a:
        s += attr("stroke-dasharray", a["dash"])
    if "cap" in a:
        s += attr("stroke-linecap", a["cap"])
    if "join" in a:
        s += attr("stroke-linejoin", a["join"])
    return s


def render_node(node, blurs, depth=1):
    pad, a, t = "  " * depth, node["a"], node["type"]
    c = common_attrs(node, blurs)
    if t == "group":
        inner = "\n".join(render_node(ch, blurs, depth + 1) for ch in node["children"])
        return f"{pad}<g{c}>\n{inner}\n{pad}</g>" if inner else f"{pad}<g{c}/>"
    if t == "rect":
        rx = a.get("rx", a.get("radius"))
        ry = a.get("ry", a.get("radius"))
        if rx is None and ry is not None:
            rx = ry
        if ry is None and rx is not None:
            ry = rx
        extra = (attr("rx", fmt(rx)) + attr("ry", fmt(ry))) if rx is not None else ""
        return f"{pad}<rect{attr('x', fmt(a['x']))}{attr('y', fmt(a['y']))}{attr('width', fmt(a['w']))}{attr('height', fmt(a['h']))}{extra}{paint_attrs(node, True)}{c}/>"
    if t == "circle":
        return f"{pad}<circle{attr('cx', fmt(a['cx']))}{attr('cy', fmt(a['cy']))}{attr('r', fmt(a['r']))}{paint_attrs(node, True)}{c}/>"
    if t == "ellipse":
        return f"{pad}<ellipse{attr('cx', fmt(a['cx']))}{attr('cy', fmt(a['cy']))}{attr('rx', fmt(a['rx']))}{attr('ry', fmt(a['ry']))}{paint_attrs(node, True)}{c}/>"
    if t == "line":
        return f"{pad}<line{attr('x1', fmt(a['x1']))}{attr('y1', fmt(a['y1']))}{attr('x2', fmt(a['x2']))}{attr('y2', fmt(a['y2']))}{paint_attrs(node, False)}{c}/>"
    if t in ("polygon", "polyline"):
        pts = " ".join(f"{fmt(x)},{fmt(y)}" for x, y in a["points"])
        return f"{pad}<{t}{attr('points', pts)}{paint_attrs(node, t == 'polygon')}{c}/>"
    if t == "path":
        return f"{pad}<path{attr('d', a['d'])}{paint_attrs(node, False)}{c}/>"
    if t == "text":
        ts = attr("x", fmt(a["x"])) + attr("y", fmt(a["y"]))
        ts += attr("font-family", a.get("font", "sans-serif")) + attr("font-size", fmt(a.get("size", 24)))
        if "weight" in a:
            ts += attr("font-weight", a["weight"])
        if a.get("italic"):
            ts += attr("font-style", "italic")
        if "anchor" in a:
            ts += attr("text-anchor", a["anchor"])
        return f"{pad}<text{ts}{paint_attrs(node, True)}{c}>{escape(a['text'])}</text>"
    raise AssertionError(t)


def to_svg(model):
    W, H = model["width"], model["height"]
    blurs = set()
    body = "\n".join(render_node(n, blurs) for n in model["nodes"])
    defs = []
    for d in model["defs"]:
        stops = "".join(f"<stop{attr('offset', fmt(o))}{attr('stop-color', c)}/>" for o, c in d["stops"])
        if d["kind"] == "linear":
            x1, y1, x2, y2 = d["coords"]
            defs.append(f"<linearGradient{attr('id', d['id'])}{attr('x1', fmt(x1))}{attr('y1', fmt(y1))}{attr('x2', fmt(x2))}{attr('y2', fmt(y2))}>{stops}</linearGradient>")
        else:
            cx, cy, r = d["coords"]
            defs.append(f"<radialGradient{attr('id', d['id'])}{attr('cx', fmt(cx))}{attr('cy', fmt(cy))}{attr('r', fmt(r))}>{stops}</radialGradient>")
    for k in sorted(blurs):
        std = k.replace("_", ".")
        defs.append(f'<filter id="dsa-blur-{k}" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="{std}"/></filter>')
    out = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}">']
    if defs:
        out.append("  <defs>\n    " + "\n    ".join(defs) + "\n  </defs>")
    if model["bg"] != "none":
        out.append(f'  <rect width="{W}" height="{H}" fill={quoteattr(model["bg"])}/>')
    if body:
        out.append(body)
    out.append("</svg>")
    return "\n".join(out) + "\n"
