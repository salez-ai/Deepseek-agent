"""
Sanitise an SVG written by the AI.

Strategy: ALLOWLIST. Parse the XML, keep only known-safe elements and attributes, and write the
result with our own serializer. Anything that could run code or fetch something is rejected
(elements) or dropped (attributes). The result is safe to open directly in a browser.
"""
import re
import xml.etree.ElementTree as ET
from xml.sax.saxutils import escape, quoteattr

MAX_BYTES = 500_000
MAX_ELEMENTS = 5000
MAX_DEPTH = 30
MAX_ATTR = 20000
SVG_NS = "http://www.w3.org/2000/svg"

ALLOWED_TAGS = {
    "svg", "g", "defs", "title", "desc", "rect", "circle", "ellipse", "line", "polyline", "polygon", "path",
    "text", "tspan", "lineargradient", "radialgradient", "stop", "clippath", "mask", "pattern", "symbol", "use",
    "filter", "fegaussianblur", "feoffset", "feflood", "fecomposite", "femerge", "femergenode", "feblend",
    "fecolormatrix",
}
# correct camelCase names for output
CANON = {"lineargradient": "linearGradient", "radialgradient": "radialGradient", "clippath": "clipPath",
         "fegaussianblur": "feGaussianBlur", "feoffset": "feOffset", "feflood": "feFlood",
         "fecomposite": "feComposite", "femerge": "feMerge", "femergenode": "feMergeNode", "feblend": "feBlend",
         "fecolormatrix": "feColorMatrix"}
TEXT_TAGS = {"text", "tspan", "title", "desc"}

PRESENTATION = {
    "fill", "stroke", "stroke-width", "stroke-opacity", "fill-opacity", "opacity", "stroke-dasharray",
    "stroke-dashoffset", "stroke-linecap", "stroke-linejoin", "stroke-miterlimit", "fill-rule", "clip-rule",
    "font-family", "font-size", "font-weight", "font-style", "text-anchor", "dominant-baseline",
    "letter-spacing", "stop-color", "stop-opacity", "flood-color", "flood-opacity", "clip-path", "mask",
    "filter", "display", "visibility",
}
ALLOWED_ATTRS = PRESENTATION | {
    "id", "x", "y", "width", "height", "rx", "ry", "cx", "cy", "r", "x1", "y1", "x2", "y2", "points", "d",
    "transform", "viewbox", "preserveaspectratio", "offset", "gradientunits", "gradienttransform", "spreadmethod",
    "fx", "fy", "fr", "patternunits", "patterncontentunits", "patterntransform", "clippathunits", "maskunits",
    "maskcontentunits", "stddeviation", "dx", "dy", "in", "in2", "result", "mode", "values", "type", "operator",
    "xmlns", "version", "href", "refx", "refy", "filterunits", "primitiveunits", "k1", "k2", "k3", "k4",
}
CAMEL = {"viewbox": "viewBox", "preserveaspectratio": "preserveAspectRatio", "gradientunits": "gradientUnits",
         "gradienttransform": "gradientTransform", "spreadmethod": "spreadMethod", "patternunits": "patternUnits",
         "patterncontentunits": "patternContentUnits", "patterntransform": "patternTransform",
         "clippathunits": "clipPathUnits", "maskunits": "maskUnits", "maskcontentunits": "maskContentUnits",
         "stddeviation": "stdDeviation", "refx": "refX", "refy": "refY", "filterunits": "filterUnits",
         "primitiveunits": "primitiveUnits"}
BAD_VALUE = re.compile(r"javascript:|vbscript:|data:|expression\s*\(|@import|<|&#|\\", re.I)
URL_FUNC = re.compile(r"url\(\s*([^)]*)\)", re.I)


class SvgError(Exception):
    pass


def _local(tag):
    """Return (namespace or '', local name lowercased) for an ElementTree tag."""
    if tag.startswith("{"):
        ns, _, name = tag[1:].partition("}")
        return ns, name.lower()
    return "", tag.lower()


def _safe_value(name, value):
    if len(value) > MAX_ATTR:
        return False
    if BAD_VALUE.search(value):
        return False
    for m in URL_FUNC.finditer(value):
        target = m.group(1).strip().strip("'\"")
        if not re.fullmatch(r"#[A-Za-z_][\w.:-]*", target):
            return False
    return True


def _clean_attrs(el, tag, dropped):
    out = {}
    for raw_name, value in el.attrib.items():
        ns, name = _local(raw_name)
        if ns and ns not in (SVG_NS, "http://www.w3.org/1999/xlink"):
            continue                                   # inkscape:, sodipodi: ... editor metadata
        if name.startswith("on"):
            dropped.append(f"{raw_name} (event handler)")
            continue
        if name == "style":
            for decl in value.split(";"):
                if ":" not in decl:
                    continue
                prop, _, val = decl.partition(":")
                prop, val = prop.strip().lower(), val.strip()
                if prop in PRESENTATION and _safe_value(prop, val):
                    out[prop] = val
                elif prop:
                    dropped.append(f"style property {prop}")
            continue
        if name == "href":
            if not re.fullmatch(r"#[A-Za-z_][\w.:-]*", value.strip()):
                dropped.append("href to something other than an element in this image")
                continue
            if tag != "use":
                continue
            out["href"] = value.strip()
            continue
        if name not in ALLOWED_ATTRS:
            dropped.append(raw_name)
            continue
        if name == "xmlns" or name == "version":
            continue                                   # we write our own
        if not _safe_value(name, value):
            dropped.append(f"{raw_name} (unsafe value)")
            continue
        out[CAMEL.get(name, name)] = value
    return out


def _number(text):
    m = re.fullmatch(r"\s*([0-9]*\.?[0-9]+)\s*(?:px)?\s*", text or "")
    return float(m.group(1)) if m else None


def sanitize(source):
    """Return (clean_svg_text, notes). Raises SvgError with a message the AI can act on."""
    if len(source.encode("utf-8")) > MAX_BYTES:
        raise SvgError(f"the SVG is larger than {MAX_BYTES // 1000} KB. Simplify it or split it up")
    if re.search(r"<!\s*(DOCTYPE|ENTITY)|<\?xml-stylesheet", source, re.I):
        raise SvgError("DOCTYPE, ENTITY and stylesheet declarations are not allowed. Start directly with <svg ...>")
    try:
        root = ET.fromstring(source.strip().encode("utf-8"))
    except ET.ParseError as e:
        raise SvgError(f"this is not well-formed XML ({e}). Check that every tag is closed and attribute values are quoted")
    ns, name = _local(root.tag)
    if name != "svg" or ns not in ("", SVG_NS):
        raise SvgError("the root element must be <svg xmlns=\"http://www.w3.org/2000/svg\" ...>")

    rejected, dropped, counter = set(), [], [0]

    def build(el, depth):
        ns, name = _local(el.tag)
        if depth > MAX_DEPTH:
            raise SvgError(f"elements are nested more than {MAX_DEPTH} levels deep")
        counter[0] += 1
        if counter[0] > MAX_ELEMENTS:
            raise SvgError(f"more than {MAX_ELEMENTS} elements")
        if ns not in ("", SVG_NS):
            return None                                # foreign namespace element: editor metadata, dropped
        if name == "metadata":
            return None
        if name not in ALLOWED_TAGS:
            rejected.add(name)
            return None
        node = {"tag": CANON.get(name, name), "attrs": _clean_attrs(el, name, dropped), "text": "", "kids": []}
        if name in TEXT_TAGS:
            node["text"] = el.text or ""
        for child in el:
            built = build(child, depth + 1)
            if built is not None:
                if name in TEXT_TAGS and child.tail:
                    built["tail"] = child.tail
                node["kids"].append(built)
        return node

    tree = build(root, 0)
    if rejected:
        raise SvgError("these elements are not allowed: " + ", ".join(sorted(rejected)) +
                       ". Allowed: shapes, paths, text, groups, gradients, patterns, clipPath, mask, filters (blur/offset/flood/merge), use (to #ids in the same file). "
                       "No script, style, image, foreignObject, a, animate or set")

    # size
    a = tree["attrs"]
    w, h = _number(a.get("width")), _number(a.get("height"))
    vb = a.get("viewBox")
    if vb:
        parts = re.split(r"[\s,]+", vb.strip())
        try:
            nums = [float(p) for p in parts]
            if len(nums) != 4 or nums[2] <= 0 or nums[3] <= 0:
                raise ValueError
        except ValueError:
            raise SvgError("viewBox must be four numbers: min-x min-y width height")
        w = w or nums[2]
        h = h or nums[3]
    elif w and h:
        a["viewBox"] = f"0 0 {w:g} {h:g}"
    else:
        raise SvgError("the <svg> needs a viewBox (e.g. viewBox=\"0 0 800 600\") or numeric width and height")
    if not (16 <= w <= 4096 and 16 <= h <= 4096):
        raise SvgError("the image size must be between 16 and 4096 in both directions")
    a["width"], a["height"] = f"{w:g}", f"{h:g}"

    def write(node, depth=0):
        pad = "  " * depth
        attrs = dict(node["attrs"])
        if depth == 0:
            attrs = {"xmlns": SVG_NS, **attrs}
        if node["tag"] == "use" and "href" in attrs:
            attrs["href"] = attrs["href"]
        s = "".join(f" {k}={quoteattr(v)}" for k, v in attrs.items())
        tag = node["tag"]
        if node["tag"] in ("title", "desc", "text", "tspan"):
            inner = escape(node["text"])
            for k in node["kids"]:
                inner += write(k, 0).strip() + escape(k.get("tail", ""))
            return f"{pad}<{tag}{s}>{inner}</{tag}>" if (inner or node["kids"]) else f"{pad}<{tag}{s}/>"
        if not node["kids"]:
            return f"{pad}<{tag}{s}/>"
        inner = "\n".join(write(k, depth + 1) for k in node["kids"])
        return f"{pad}<{tag}{s}>\n{inner}\n{pad}</{tag}>"

    notes = []
    if dropped:
        uniq = sorted(set(dropped))
        notes.append("removed unsafe or unsupported attributes: " + ", ".join(uniq[:8]) + (" ..." if len(uniq) > 8 else ""))
    return write(tree) + "\n", notes
