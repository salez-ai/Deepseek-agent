#!/usr/bin/env python3
"""
canvas-draw tools: draw, draw_svg, draw_list, draw_remove, draw_files.

Protocol (input: json): request on stdin, answer on stdout. Standard library only.
Files are written to <project>/drawings/<name>.svg. The editable scene is kept next to it in
<project>/drawings/.<name>.model.json so a drawing can be extended, edited by id and listed.
"""
import json
import os
import re
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import dsl                      # noqa: E402
import svgclean                 # noqa: E402

NAME_RE = re.compile(r"^[a-z0-9][a-z0-9_-]{0,40}$")
FOOTER = ("You cannot see the image, but the user can: it is shown in the chat. "
          "Ask the user what to change instead of guessing, and fix problems by redrawing shapes with the same id.")


class Fail(Exception):
    pass


def fail(msg):
    print(json.dumps({"ok": False, "error": msg}))
    sys.exit(0)


def paths(project, name):
    if not NAME_RE.match(name or ""):
        raise Fail("name must be 1-41 characters: lowercase letters, digits, - and _ (for example: sunset-scene)")
    root = Path(project).resolve()
    d = root / "drawings"
    if d.is_symlink() or d.exists():
        real = d.resolve()
        if real != root and root not in real.parents:      # e.g. drawings -> /somewhere/else
            raise Fail("the project's drawings folder points outside the project, so nothing was written")
    return d, d / f"{name}.svg", d / f".{name}.model.json"


def atomic_write(path, text):
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix=".tmp-")
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as f:
            f.write(text)
        os.replace(tmp, path)
    except Exception:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def load_model(svg_path, model_path, need_dsl=True):
    if not svg_path.exists():
        raise Fail(f"there is no drawing called '{svg_path.stem}' yet. Create it with the draw tool first (draw_files lists existing drawings)")
    if not model_path.exists():
        if need_dsl:
            raise Fail(f"'{svg_path.stem}' was written as raw SVG (draw_svg), so it has no editable shapes. Redraw it with the draw tool (mode: new) or send a new draw_svg")
        return None
    try:
        return json.loads(model_path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        raise Fail(f"the saved scene for '{svg_path.stem}' is damaged. Redraw it with the draw tool (mode: new)")


def save_model(svg_path, model_path, model):
    atomic_write(svg_path, dsl.to_svg(model))
    atomic_write(model_path, json.dumps(model))


def kinds(model):
    counts = {}
    for n, _ in dsl.walk(model["nodes"]):
        counts[n["type"]] = counts.get(n["type"], 0) + 1
    return ", ".join(f"{v} {k}" for k, v in sorted(counts.items(), key=lambda kv: -kv[1])) or "nothing"


def rel(project, p):
    return Path(p).resolve().relative_to(Path(project).resolve()).as_posix()


def tool_draw(req):
    p, body, project = req["params"], req.get("body") or "", req["project_dir"]
    name, mode = p["drawing"], p.get("mode", "new")
    if not body.strip():
        raise Fail("the drawing script is empty. Put the commands between =====BODY===== and =====END=====")
    _, svg_path, model_path = paths(project, name)
    base = dsl.new_model()
    if mode == "append":
        base = load_model(svg_path, model_path)
    try:
        model, warnings, replaced = dsl.apply_script(base, body, append=(mode == "append"))
    except dsl.DrawError as e:
        more = "\nNothing was saved. Fix these and send the whole script again:\n"
        raise Fail(more + "\n".join("- " + x for x in e.errors))
    save_model(svg_path, model_path, model)
    out = [f"{'Added to' if mode == 'append' else 'Drew'} {rel(project, svg_path)} "
           f"({model['width']}x{model['height']}, {dsl.count_shapes(model)} shapes: {kinds(model)})",
           f"IMAGE: {rel(project, svg_path)}"]
    if replaced:
        out.append("Replaced existing shapes: " + ", ".join(replaced))
    if warnings:
        out.append("Warnings:\n" + "\n".join("- " + w for w in warnings))
    out.append(FOOTER)
    return "\n".join(out)


def tool_draw_svg(req):
    name, body, project = req["params"]["drawing"], req.get("body") or "", req["project_dir"]
    if not body.strip():
        raise Fail("the SVG is empty. Put the <svg>...</svg> markup between =====BODY===== and =====END=====")
    _, svg_path, model_path = paths(project, name)
    try:
        clean, notes = svgclean.sanitize(body)
    except svgclean.SvgError as e:
        raise Fail(f"Nothing was saved: {e}")
    atomic_write(svg_path, clean)
    if model_path.exists():
        model_path.unlink()          # the old editable scene no longer matches the file
    out = [f"Saved {rel(project, svg_path)} ({len(clean) // 1024 + 1} KB, raw SVG, not editable with draw_list/draw_remove)",
           f"IMAGE: {rel(project, svg_path)}"]
    if notes:
        out.append("Note: " + "; ".join(notes))
    out.append(FOOTER)
    return "\n".join(out)


def tool_draw_list(req):
    _, svg_path, model_path = paths(req["project_dir"], req["params"]["drawing"])
    m = load_model(svg_path, model_path)
    lines = [f"{svg_path.stem}: canvas {m['width']}x{m['height']}, background {m['bg']}, "
             f"{dsl.count_shapes(m)} shapes (drawn first = at the back)"]
    for d in m["defs"]:
        lines.append(f"{d['id']} {d['kind']}gradient, {len(d['stops'])} stops")
    for n, depth in dsl.walk(m["nodes"]):
        lines.append("  " * depth + dsl.describe(n))
    return "\n".join(lines)


def tool_draw_remove(req):
    name, project = req["params"]["drawing"], req["project_dir"]
    ids = [x for x in re.split(r"[,\s]+", req["params"]["ids"].strip()) if x]
    if not ids:
        raise Fail("ids is empty. Give shape ids separated by commas (see draw_list)")
    _, svg_path, model_path = paths(project, name)
    model = load_model(svg_path, model_path)
    removed, missing = dsl.remove_ids(model, ids)
    if missing:
        have = sorted({n["id"] for n, _ in dsl.walk(model["nodes"])} | {d["id"] for d in model["defs"]})
        raise Fail(f"no shape or gradient with id: {', '.join(missing)}. Nothing was removed. Existing ids: {', '.join(have[:60])}")
    left = {d["id"] for d in model["defs"]}
    for n, _ in dsl.walk(model["nodes"]):
        for k in ("fill", "stroke"):
            m = dsl.URL_RE.match(str(n["a"].get(k, "")))
            if m and m.group(1) not in left:
                raise Fail(f"cannot remove gradient '{m.group(1)}': shape {n['id']} still uses it. Remove or redraw that shape first")
    save_model(svg_path, model_path, model)
    return "\n".join([f"Removed {', '.join(removed)}. {dsl.count_shapes(model)} shapes remain in {rel(project, svg_path)}",
                      f"IMAGE: {rel(project, svg_path)}", FOOTER])


def tool_draw_files(req):
    d = Path(req["project_dir"]).resolve() / "drawings"
    files = sorted(d.glob("*.svg")) if d.is_dir() else []
    if not files:
        return "No drawings yet. Create one with the draw tool."
    out = [f"{len(files)} drawing(s) in drawings/:"]
    for f in files:
        mp = d / f".{f.stem}.model.json"
        try:
            kind = f"{dsl.count_shapes(json.loads(mp.read_text(encoding='utf-8')))} shapes, editable" if mp.exists() else "raw SVG"
        except (OSError, ValueError):
            kind = "scene file damaged"
        out.append(f"- {f.stem}  ({f.stat().st_size // 1024 + 1} KB, {kind})")
    return "\n".join(out)


TOOLS = {"draw": tool_draw, "draw_svg": tool_draw_svg, "draw_list": tool_draw_list,
         "draw_remove": tool_draw_remove, "draw_files": tool_draw_files}


def main():
    req = json.load(sys.stdin)
    fn = TOOLS.get(req["tool"])
    if not fn:
        fail(f"unknown tool {req['tool']}")
    try:
        print(fn(req))
    except Fail as e:
        fail(str(e))


if __name__ == "__main__":
    main()
