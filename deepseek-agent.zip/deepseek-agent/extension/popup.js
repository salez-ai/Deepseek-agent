const DEFAULTS = { bridgeUrl: 'http://127.0.0.1:8765', token: '' };
const $ = (id) => document.getElementById(id);

function show(text, cls) {
  const m = $('msg');
  m.textContent = text;
  m.className = cls || '';
}

async function test() {
  show('Testing...');
  const res = await chrome.runtime.sendMessage({ type: 'bridge', path: '/ping' });
  if (res && res.ok) show('Connected. Project: ' + res.root, 'ok');
  else show((res && res.error) || 'No response', 'err');
}

const OPTIONS = { collapseThinking: true, collapseTools: true, collapseAgentMsgs: true, theme: true };

(async () => {
  const opts = await chrome.storage.local.get(OPTIONS);   // saved the moment you tick a box
  for (const key of Object.keys(OPTIONS)) {
    const box = $(key);
    box.checked = !!opts[key];
    box.addEventListener('change', () => chrome.storage.local.set({ [key]: box.checked }));
  }
  const saved = await chrome.storage.local.get(DEFAULTS);
  $('url').value = saved.bridgeUrl;
  $('token').value = saved.token;
  if (saved.token) test();
})();

$('save').addEventListener('click', async () => {
  const bridgeUrl = $('url').value.trim() || DEFAULTS.bridgeUrl;
  if (!/^http:\/\/(127\.0\.0\.1|localhost)(:\d+)?\/?$/.test(bridgeUrl)) {
    show('The address must be http://127.0.0.1:<port> or http://localhost:<port>', 'err');
    return;
  }
  await chrome.storage.local.set({ bridgeUrl, token: $('token').value.trim() });
  test();
});

// ---- alerts ------------------------------------------------------------------------------------
const ALERT = DSAgentAlert.DEFAULTS;
(async () => {
  const a = await chrome.storage.local.get(ALERT);
  $('alertSound').checked = !!a.alertSound;
  $('alertNotify').checked = !!a.alertNotify;
  $('alertTone').value = a.alertTone;
  $('alertVolume').value = Math.round(a.alertVolume * 100);
  const rep = $('alertRepeatSec');
  if (![...rep.options].some((o) => o.value === String(a.alertRepeatSec))) {   // a value set elsewhere, e.g. 45
    const o = new Option(`after ${a.alertRepeatSec} s`, String(a.alertRepeatSec));
    rep.add(o);
  }
  rep.value = String(a.alertRepeatSec);
  DSAgentAlert.configure(a);
})();
const saveAlert = (patch) => { chrome.storage.local.set(patch); DSAgentAlert.configure(patch); };
$('alertSound').addEventListener('change', (e) => saveAlert({ alertSound: e.target.checked }));
$('alertNotify').addEventListener('change', (e) => saveAlert({ alertNotify: e.target.checked }));
$('alertTone').addEventListener('change', (e) => { saveAlert({ alertTone: e.target.value }); DSAgentAlert.test('approval'); });
$('alertVolume').addEventListener('input', (e) => saveAlert({ alertVolume: +e.target.value / 100 }));
$('alertVolume').addEventListener('change', () => DSAgentAlert.test('approval'));
$('alertRepeatSec').addEventListener('change', (e) => saveAlert({ alertRepeatSec: +e.target.value }));
$('testSound').addEventListener('click', () => DSAgentAlert.test('approval'));
$('testNotify').addEventListener('click', () => DSAgentAlert.test('notification'));

$('skills').addEventListener('click', () => { chrome.runtime.openOptionsPage(); window.close(); });
