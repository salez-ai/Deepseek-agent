// The content script runs inside chat.deepseek.com, whose CSP and CORS rules
// would block calls to localhost. The service worker is not bound by them, so
// every bridge request is relayed through here.

const DEFAULTS = { bridgeUrl: 'http://127.0.0.1:8765', token: '' };

async function callBridge({ path, body }) {
  const { bridgeUrl, token } = await chrome.storage.local.get(DEFAULTS);
  const base = String(bridgeUrl || DEFAULTS.bridgeUrl).replace(/\/+$/, '');
  if (!token) {
    return { ok: false, error: 'No token set. Click the extension icon and paste the token printed by the bridge.' };
  }
  try {
    const res = await fetch(base + path, {
      method: body ? 'POST' : 'GET',
      headers: { 'Content-Type': 'application/json', 'X-Agent-Token': token },
      body: body ? JSON.stringify(body) : undefined,
    });
    const data = await res.json().catch(() => null);
    if (res.status === 401) {
      return { ok: false, error: 'The bridge rejected the token. Copy it again from the bridge window.' };
    }
    return data || { ok: false, error: `Unexpected response (HTTP ${res.status})` };
  } catch (e) {
    return { ok: false, error: `Cannot reach the bridge at ${base}. Is bridge.py running?` };
  }
}

// Download an image from the project through the bridge and hand it back as base64.
async function fetchFile(path) {
  const { bridgeUrl, token } = await chrome.storage.local.get(DEFAULTS);
  const base = String(bridgeUrl || DEFAULTS.bridgeUrl).replace(/\/+$/, '');
  if (!token) return { ok: false, error: 'No token set.' };
  try {
    const res = await fetch(base + '/file?path=' + encodeURIComponent(path), { headers: { 'X-Agent-Token': token } });
    if (!res.ok) {
      let msg = `HTTP ${res.status}`;
      try { msg = (await res.json()).error || msg; } catch (e) { /* not JSON */ }
      return { ok: false, error: msg };
    }
    const mime = (res.headers.get('Content-Type') || '').split(';')[0];
    const bytes = new Uint8Array(await res.arrayBuffer());
    let bin = '';
    for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
    return { ok: true, mime, size: bytes.length, data: btoa(bin) };
  } catch (e) {
    return { ok: false, error: 'Cannot reach the bridge.' };
  }
}

// ---- desktop notifications --------------------------------------------------------------------
// Notification ids look like  dsa|<tabId>|<windowId>|<kind>|<time>  so a click can find its tab.
const NOTIFY_KINDS = ['approval', 'continue', 'paused', 'error', 'done'];

function showNotification(msg, sender) {
  const kind = NOTIFY_KINDS.includes(msg.kind) ? msg.kind : 'approval';
  const tab = (sender && sender.tab) || {};
  const id = `dsa|${tab.id || 0}|${tab.windowId || 0}|${kind}|${Date.now()}`;
  chrome.notifications.create(id, {
    type: 'basic',
    iconUrl: 'icons/icon128.png',
    title: String(msg.title || 'DeepSeek Agent').slice(0, 80),
    message: String(msg.message || '').slice(0, 220),
    priority: 2,
    requireInteraction: !!msg.urgent,   // stays until you click it (Windows/Linux; macOS ignores this)
    silent: true,                       // the extension plays its own ringtone
  }, () => { void chrome.runtime.lastError; });
  return id;
}

function clearNotifications(kind, sender) {
  const tabId = sender && sender.tab ? String(sender.tab.id) : null;
  chrome.notifications.getAll((all) => {
    for (const id of Object.keys(all || {})) {
      const [prefix, t, , k] = id.split('|');
      if (prefix === 'dsa' && (tabId === null || t === tabId) && (!kind || k === kind)) chrome.notifications.clear(id);
    }
  });
}

function handleNotificationClick(id) {
  const [prefix, tabId, windowId] = String(id).split('|');
  if (prefix !== 'dsa') return;
  if (+tabId) chrome.tabs.update(+tabId, { active: true }).catch(() => {});
  if (+windowId) chrome.windows.update(+windowId, { focused: true }).catch(() => {});
  chrome.notifications.clear(id);
}
chrome.notifications.onClicked.addListener(handleNotificationClick);

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.type === 'notify') {
    sendResponse({ ok: true, id: showNotification(msg, sender) });
    return false;
  }
  if (msg && msg.type === 'clearNotify') {
    clearNotifications(msg.kind, sender);
    sendResponse({ ok: true });
    return false;
  }
  if (msg && msg.type === 'bridgeFile') {
    fetchFile(String(msg.path || '')).then(sendResponse);
    return true;
  }
  if (msg && msg.type === 'openImage') {
    chrome.tabs.create({ url: chrome.runtime.getURL('viewer.html') + '?path=' + encodeURIComponent(String(msg.path || '')) });
    sendResponse({ ok: true });
    return false;
  }
  if (msg && msg.type === 'bridge') {
    callBridge(msg).then(sendResponse);
    return true; // async response
  }
  if (msg && msg.type === 'openOptions') {
    chrome.runtime.openOptionsPage();
    sendResponse({ ok: true });
  }
  return false;
});
