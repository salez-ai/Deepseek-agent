"""
Tests for the native messaging helper. Each call starts a fresh helper process and speaks
Chrome's wire protocol (4-byte length prefix + JSON), exactly like chrome.runtime.sendNativeMessage.

    python -m unittest tests/test_native_host.py -v

Uses ports 8765-8800 and a temporary HOME, so it never touches your real ~/.dsagent.
"""
import json
import os
import shutil
import signal
import socket
import stat
import struct
import subprocess
import sys
import tempfile
import threading
import time
import unittest
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
BRIDGE_DIR = ROOT / "bridge"
HOST = BRIDGE_DIR / "native_host.py"


def alive(pid):
    try:
        with open(f"/proc/{pid}/stat") as f:                 # a zombie counts as dead
            return f.read().rsplit(")", 1)[1].split()[0] != "Z"
    except OSError:
        try:
            os.kill(pid, 0)
            return True
        except OSError:
            return False


def wait_dead(pid, seconds=8):
    end = time.time() + seconds
    while time.time() < end:
        if not alive(pid):
            return True
        time.sleep(0.1)
    return False


class HostCase(unittest.TestCase):
    host = HOST

    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.tmp = Path(self._tmp.name).resolve()
        self.home = self.tmp / "home"
        self.home.mkdir()
        self.proj = self.tmp / "proj"
        self.proj.mkdir()
        self.env = dict(os.environ, HOME=str(self.home), USERPROFILE=str(self.home), SHELL="/nonexistent-shell")
        self.pids = set()

    def tearDown(self):
        info = self.home / ".dsagent" / "bridge.json"
        try:
            self.pids.add(json.loads(info.read_text())["pid"])
        except (OSError, ValueError, KeyError):
            pass
        for pid in self.pids:
            try:
                os.kill(pid, signal.SIGKILL)
            except OSError:
                pass
        self._tmp.cleanup()

    # -- the wire protocol --------------------------------------------------
    def spawn(self):
        return subprocess.Popen([sys.executable, str(self.host)], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE, env=self.env)

    @staticmethod
    def frame(obj):
        data = json.dumps(obj).encode()
        return struct.pack("=I", len(data)) + data

    @staticmethod
    def read_reply(p):
        raw = p.stdout.read(4)
        if len(raw) < 4:
            return None
        (n,) = struct.unpack("=I", raw)
        return json.loads(p.stdout.read(n))

    def call(self, msg):
        p = self.spawn()
        p.stdin.write(self.frame(msg))
        p.stdin.flush()
        reply = self.read_reply(p)
        p.stdin.close()
        p.wait(timeout=20)
        p.stdout.close()
        p.stderr.close()
        return reply

    def token(self):
        return (self.home / ".dsagent" / "token").read_text().strip()

    def ping(self, port):
        req = urllib.request.Request(f"http://127.0.0.1:{port}/ping", headers={"X-Agent-Token": self.token()})
        return json.loads(urllib.request.urlopen(req, timeout=3).read())

    def start(self, root=None, **kw):
        r = self.call({"cmd": "start", "root": str(root or self.proj), **kw})
        if r.get("ok"):
            self.pids.add(r["pid"])
        return r


class Protocol(HostCase):
    def test_hello(self):
        r = self.call({"cmd": "hello"})
        self.assertTrue(r["ok"])
        self.assertEqual(r["version"], 1)
        self.assertTrue(r["bridge_present"])
        self.assertEqual(r["home"], str(self.home))

    def test_unknown_and_missing_commands(self):
        self.assertEqual(self.call({"cmd": "format_disk"})["code"], "unknown_command")
        self.assertEqual(self.call({})["code"], "unknown_command")
        self.assertEqual(self.call({"cmd": "__import__('os')"})["code"], "unknown_command")

    def test_several_messages_on_one_connection(self):          # chrome.runtime.connectNative style
        p = self.spawn()
        for _ in range(3):
            p.stdin.write(self.frame({"cmd": "hello"}))
        p.stdin.flush()
        replies = [self.read_reply(p) for _ in range(3)]
        p.stdin.close()
        p.wait(timeout=10)
        self.assertTrue(all(r and r["ok"] for r in replies))

    def test_garbage_does_not_crash_it(self):
        p = self.spawn()
        p.stdin.write(struct.pack("=I", 5) + b"{nope")
        p.stdin.flush()
        r = self.read_reply(p)
        p.wait(timeout=10)
        self.assertEqual(r["code"], "bad_request")
        self.assertEqual(p.returncode, 0)

    def test_oversized_request_is_refused(self):
        p = self.spawn()
        p.stdin.write(struct.pack("=I", 50 * 1024 * 1024))
        p.stdin.flush()
        r = self.read_reply(p)
        p.wait(timeout=10)
        self.assertEqual(r["code"], "too_large")

    def test_truncated_message_and_non_object_json(self):
        p = self.spawn()
        p.stdin.write(struct.pack("=I", 100) + b"short")
        p.stdin.close()
        p.wait(timeout=10)
        self.assertEqual(p.returncode, 0)
        p = self.spawn()
        p.stdin.write(self.frame([1, 2, 3]))
        p.stdin.flush()
        self.assertEqual(self.read_reply(p)["code"], "bad_request")
        p.wait(timeout=10)

    def test_stdout_stays_clean_even_if_code_prints(self):
        p = self.spawn()
        p.stdin.write(self.frame({"cmd": "hello"}))
        p.stdin.close()
        raw = p.stdout.read()
        (n,) = struct.unpack("=I", raw[:4])
        self.assertEqual(len(raw), 4 + n, "nothing but the framed reply may appear on stdout")
        p.wait(timeout=10)


class ListDir(HostCase):
    def test_lists_only_visible_folders_sorted(self):
        for name in ("beta", "Alpha", "gamma", ".hidden", "$RECYCLE.BIN"):
            (self.proj / name).mkdir()
        (self.proj / "file.txt").write_text("x")
        r = self.call({"cmd": "list_dir", "path": str(self.proj)})
        self.assertEqual(r["dirs"], ["Alpha", "beta", "gamma"])
        self.assertEqual(r["path"], str(self.proj))
        self.assertEqual(r["parent"], str(self.tmp))

    def test_defaults_to_home_and_offers_quick_links(self):
        (self.home / "Documents").mkdir()
        (self.home / "code").mkdir()
        r = self.call({"cmd": "list_dir"})
        self.assertEqual(r["path"], str(self.home))
        names = [q["name"] for q in r["quick"]]
        self.assertIn("Home", names)
        self.assertIn("Documents", names)
        self.assertIn("code", names)
        self.assertNotIn("Downloads", names)                      # only folders that exist

    def test_errors(self):
        self.assertEqual(self.call({"cmd": "list_dir", "path": str(self.tmp / "nope")})["code"], "not_found")
        (self.tmp / "f.txt").write_text("x")
        self.assertEqual(self.call({"cmd": "list_dir", "path": str(self.tmp / "f.txt")})["code"], "not_dir")
        self.assertEqual(self.call({"cmd": "list_dir", "path": "relative/path"})["code"], "bad_path")

    @unittest.skipIf(os.name == "nt" or os.geteuid() == 0, "needs a non-root POSIX user")
    def test_unreadable_folder(self):
        d = self.proj / "locked"
        d.mkdir()
        d.chmod(0)
        try:
            self.assertEqual(self.call({"cmd": "list_dir", "path": str(d)})["code"], "denied")
        finally:
            d.chmod(stat.S_IRWXU)

    def test_filesystem_root_has_no_parent(self):
        self.assertIsNone(self.call({"cmd": "list_dir", "path": os.path.abspath(os.sep)})["parent"])

    def test_big_folders_are_capped_to_fit_one_reply(self):
        for i in range(620):
            (self.proj / f"d{i:04d}").mkdir()
        r = self.call({"cmd": "list_dir", "path": str(self.proj)})
        self.assertTrue(r["ok"])
        self.assertEqual(len(r["dirs"]), 500)
        self.assertTrue(r["truncated"])


class Lifecycle(HostCase):
    def test_start_status_reuse_switch_stop(self):
        self.assertFalse(self.call({"cmd": "status"})["running"])

        r = self.start()
        self.assertTrue(r["ok"], r)
        self.assertFalse(r["reused"])
        self.assertEqual(r["token"], self.token())
        self.assertGreaterEqual(r["port"], 8765)
        self.assertEqual(self.ping(r["port"])["pid"], r["pid"])
        self.assertTrue(alive(r["pid"]), "the bridge must outlive the helper process that started it")

        st = self.call({"cmd": "status"})
        self.assertTrue(st["running"])
        self.assertEqual((st["port"], st["pid"], st["managed"]), (r["port"], r["pid"], True))
        self.assertEqual(st["root"], str(self.proj))

        again = self.start()
        self.assertTrue(again["reused"])
        self.assertEqual(again["pid"], r["pid"])

        proj2 = self.tmp / "proj2"
        proj2.mkdir()
        sw = self.start(proj2)
        self.assertTrue(sw["ok"], sw)
        self.assertNotEqual(sw["pid"], r["pid"])
        self.assertEqual(sw["root"], str(proj2))
        self.assertTrue(wait_dead(r["pid"]), "the previous project's bridge must be stopped")

        stopped = self.call({"cmd": "stop"})
        self.assertTrue(stopped["stopped"])
        self.assertTrue(wait_dead(sw["pid"]))
        self.assertFalse(self.call({"cmd": "status"})["running"])
        self.assertFalse((self.home / ".dsagent" / "bridge.json").exists())
        self.assertEqual(self.call({"cmd": "stop"}), {"ok": True, "stopped": False})

    def test_the_started_bridge_really_works(self):
        r = self.start()
        req = urllib.request.Request(f"http://127.0.0.1:{r['port']}/call", method="POST",
                                     data=json.dumps({"name": "write_file", "args": {"path": "hi.txt", "content": "hello\n"}}).encode(),
                                     headers={"X-Agent-Token": r["token"], "Content-Type": "application/json"})
        self.assertTrue(json.loads(urllib.request.urlopen(req, timeout=5).read())["ok"])
        self.assertEqual((self.proj / "hi.txt").read_text(), "hello\n")

    @unittest.skipUnless(sys.platform.startswith("linux"), "reads /proc")
    def test_started_with_idle_timeout_and_managed_flag(self):
        r = self.start()
        cmdline = Path(f"/proc/{r['pid']}/cmdline").read_bytes().split(b"\0")
        self.assertIn(b"--managed", cmdline)
        self.assertIn(b"--idle-timeout", cmdline)

    def test_refuses_dangerous_or_wrong_roots(self):
        (self.tmp / "f.txt").write_text("x")
        cases = [(os.path.abspath(os.sep), "risky_root"), (str(self.home), "risky_root"),
                 (str(self.tmp / "nope"), "not_found"), (str(self.tmp / "f.txt"), "not_dir"),
                 ("relative/dir", "bad_root"), ("", "bad_root"), (None, "bad_root")]
        for root, code in cases:
            r = self.call({"cmd": "start", "root": root})
            self.assertFalse(r["ok"], root)
            self.assertEqual(r["code"], code, (root, r))
        self.assertFalse(self.call({"cmd": "status"})["running"])

    def test_stale_info_file_is_cleaned_up(self):
        d = self.home / ".dsagent"
        d.mkdir(parents=True, exist_ok=True)
        (d / "token").write_text("tok")
        (d / "bridge.json").write_text(json.dumps({"pid": 999999, "port": 8799, "root": str(self.proj), "managed": True}))
        self.assertFalse(self.call({"cmd": "status"})["running"])
        self.assertFalse((d / "bridge.json").exists())

    def test_crashed_bridge_is_noticed_and_restarted(self):
        r = self.start()
        os.kill(r["pid"], signal.SIGKILL)
        self.assertTrue(wait_dead(r["pid"]))
        self.assertFalse(self.call({"cmd": "status"})["running"])
        r2 = self.start()
        self.assertTrue(r2["ok"])
        self.assertNotEqual(r2["pid"], r["pid"])

    def test_bridge_started_from_a_terminal_is_never_stopped_or_killed(self):
        token_dir = self.home / ".dsagent"
        proc = subprocess.Popen([sys.executable, str(BRIDGE_DIR / "bridge.py"), "--root", str(self.proj), "--port", "8765"],
                                env=self.env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        self.pids.add(proc.pid)
        for _ in range(50):
            if (token_dir / "bridge.json").exists():
                break
            time.sleep(0.1)
        same = self.start()
        self.assertTrue(same["reused"], same)
        self.assertEqual((same["pid"], same["port"]), (proc.pid, 8765))
        self.assertEqual(self.call({"cmd": "stop"})["code"], "not_managed")
        self.assertIsNone(proc.poll(), "still running")
        other = self.tmp / "other"
        other.mkdir()
        sw = self.start(other)
        self.assertTrue(sw["ok"], sw)
        self.assertNotEqual(sw["port"], 8765)
        self.assertIsNone(proc.poll(), "the terminal bridge must be left alone when another project is opened")
        proc.terminate()
        proc.wait(timeout=10)

    def test_busy_port_is_skipped(self):
        s = socket.socket()
        s.bind(("127.0.0.1", 8765))
        s.listen(1)
        try:
            r = self.start()
            self.assertTrue(r["ok"], r)
            self.assertNotEqual(r["port"], 8765)
            self.assertEqual(self.ping(r["port"])["pid"], r["pid"])
        finally:
            s.close()

    def test_simultaneous_starts_end_with_one_bridge(self):
        results = []

        def go():
            results.append(self.start())

        threads = [threading.Thread(target=go) for _ in range(3)]
        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=60)
        self.assertEqual(len(results), 3)
        self.assertTrue(all(r["ok"] for r in results), results)
        self.assertEqual(len({r["pid"] for r in results}), 1, "all callers must end up with the same bridge")

    def test_log_command(self):
        self.start()
        self.assertIn("starting bridge", self.call({"cmd": "log"})["log"])

    def test_agent_commands_see_the_users_login_path(self):
        fake_shell = self.tmp / "fakeshell"
        fake_shell.write_text('#!/bin/sh\necho "some noise from a profile script"\nprintf "%s" "/opt/custom/bin:/usr/bin"\n')
        fake_shell.chmod(0o755)
        self.env["SHELL"] = str(fake_shell)
        self.env["PATH"] = "/usr/bin:/bin"                      # what a Dock-launched browser would pass on
        r = self.start()
        req = urllib.request.Request(f"http://127.0.0.1:{r['port']}/call", method="POST",
                                     data=json.dumps({"name": "run_command", "args": {"command": "echo $PATH"}}).encode(),
                                     headers={"X-Agent-Token": r["token"], "Content-Type": "application/json"})
        out = json.loads(urllib.request.urlopen(req, timeout=10).read())["output"]
        self.assertIn("/opt/custom/bin", out)
        self.assertIn("/usr/bin", out)
        self.assertEqual(out.count("/usr/bin"), 1, "no duplicate PATH entries")


class StartFailures(HostCase):
    """Use a copy of the helper next to a bridge that cannot start, to check the error the user sees."""

    def test_bridge_that_dies_reports_its_own_message(self):
        d = self.tmp / "fakeapp"
        d.mkdir()
        shutil.copy(HOST, d / "native_host.py")
        real = (BRIDGE_DIR / "bridge.py").read_text()
        stub = (f"import sys\nfrom pathlib import Path\n"
                f"def load_token(rotate=False):\n    p = Path.home() / '.dsagent' / 'token'\n    p.parent.mkdir(parents=True, exist_ok=True)\n"
                f"    p.write_text('t'); return 't', p\n"
                f"def risky_root_reason(root):\n    return ''\n"
                f"if __name__ == '__main__':\n    print('boom: something is wrong', file=sys.stderr)\n    sys.exit(3)\n")
        (d / "bridge.py").write_text(stub)
        self.host = d / "native_host.py"
        r = self.call({"cmd": "start", "root": str(self.proj)})
        self.assertFalse(r["ok"])
        self.assertEqual(r["code"], "start_failed")
        self.assertIn("boom: something is wrong", r["error"])


if __name__ == "__main__":
    unittest.main()
