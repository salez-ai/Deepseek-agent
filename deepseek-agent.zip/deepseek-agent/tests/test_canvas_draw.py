"""
Tests for the canvas-draw skill (no third-party packages needed).

    python -m unittest tests/test_canvas_draw.py -v
"""
import json
import os
import re
import sys
import tempfile
import unittest
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SKILL = ROOT / "examples" / "skills" / "canvas-draw"
sys.path.insert(0, str(SKILL / "tools"))
sys.path.insert(0, str(ROOT / "bridge"))

import dsl            # noqa: E402
import svgclean       # noqa: E402
from skills import ToolError, files_from_dir, parse_manifest, run_tool   # noqa: E402

SVG_NS = "{http://www.w3.org/2000/svg}"


def build(script, model=None, append=False):
    return dsl.apply_script(model or dsl.new_model(), script, append)


def render(script):
    model, _, _ = build(script)
    svg = dsl.to_svg(model)
    ET.fromstring(svg)                       # must always be well-formed XML
    return svg


def errors_of(script, model=None, append=False):
    try:
        build(script, model, append)
    except dsl.DrawError as e:
        return e.errors
    return []


class Tokenizer(unittest.TestCase):
    def test_quotes_comments_and_keyed_values(self):
        t = dsl.tokenize('text 10 20 "Hello world" fill=#fff d="M 0 0 L 9 9" # trailing comment', 1)
        self.assertEqual([x[1] for x in t], ["text", "10", "20", "Hello world", "#fff", "M 0 0 L 9 9"])
        self.assertEqual([x[0] for x in t], [None, None, None, None, "fill", "d"])

    def test_escaped_quote(self):
        t = dsl.tokenize(r'text 1 2 "say \"hi\""', 1)
        self.assertEqual(t[3][1], 'say "hi"')

    def test_unterminated_quote(self):
        with self.assertRaises(dsl.DrawError):
            dsl.tokenize('text 1 2 "oops', 7)


class Rendering(unittest.TestCase):
    def test_all_commands_render_valid_xml(self):
        svg = render("""
            canvas 400 300 bg=#112233
            lineargradient g1 0 0 0 1 0:#fff 1:#000
            radialgradient g2 0.5 0.5 0.5 0:red 100%:blue
            rect 10 10 100 50 radius=8 fill=url(#g1) id=r
            circle 200 100 40 fill=url(#g2) stroke=black sw=2
            ellipse 300 200 50 20 fill=teal rotate=30
            line 0 0 400 300 stroke=#f00 dash="8 4" cap=round
            polygon 10,200 60,150 110,200 fill=gold
            polyline 10,250 60,280 110,250 stroke=navy sw=3
            path d="M 150 250 Q 200 200 250 250 Z" fill=pink
            text 200 40 "Title" anchor=middle size=30 weight=bold italic=true font="Georgia, serif"
            group translate=5,5 rotate=10@50,50 scale=1.5 opacity=0.8 blur=2
              rect 0 0 10 10 fill=lime
            end
        """)
        root = ET.fromstring(svg)
        tags = [e.tag.replace(SVG_NS, "") for e in root.iter()]
        for needed in ("linearGradient", "radialGradient", "rect", "circle", "ellipse", "line", "polygon",
                       "polyline", "path", "text", "g", "filter", "feGaussianBlur"):
            self.assertIn(needed, tags)
        self.assertEqual(root.get("viewBox"), "0 0 400 300")

    def test_defaults(self):
        svg = render("rect 0 0 10 10\nline 0 0 5 5\npath d=\"M 0 0 L 5 5\"\npath d=\"M 0 0 L 5 5 Z\" fill=red")
        els = [e for e in ET.fromstring(svg) if e.tag != SVG_NS + "rect" or e.get("width") == "10"]
        rect, line, path1, path2 = [e for e in ET.fromstring(svg) if e.get("id", "").startswith("s")]
        self.assertEqual((rect.get("fill"), rect.get("stroke")), ("#000000", "none"))
        self.assertEqual((line.get("fill"), line.get("stroke")), ("none", "#000000"))
        self.assertEqual((path1.get("fill"), path1.get("stroke")), ("none", "#000000"))
        self.assertEqual((path2.get("fill"), path2.get("stroke")), ("red", "none"))

    def test_number_styles_are_interchangeable(self):
        a = render("rect 10 20 100 50")
        b = render("rect 10,20 100,50")
        self.assertEqual(a, b)
        self.assertEqual(render("line 1 2 3 4"), render("line 1,2 3,4"))

    def test_rotate_uses_shape_centre_by_default(self):
        svg = render("rect 0 0 100 50 rotate=90")
        el = [e for e in ET.fromstring(svg) if e.get("id") == "s1"][0]
        self.assertEqual(el.get("transform"), "rotate(90 50 25)")

    def test_unicode_text_survives(self):
        text = "Salam, dünya! 你好 مرحبا 🌅 <&>"
        svg = render(f'text 10 40 "{text}"')
        el = [e for e in ET.fromstring(svg).iter(SVG_NS + "text")][0]
        self.assertEqual(el.text, text)


class Errors(unittest.TestCase):
    def check(self, script, expect, **kw):
        errs = errors_of(script, **kw)
        self.assertTrue(errs, f"expected an error for: {script!r}")
        self.assertTrue(any(expect in e for e in errs), f"{expect!r} not in {errs}")
        return errs

    def test_messages_have_line_numbers_and_say_what_is_needed(self):
        errs = self.check("canvas 100 100\nrect 1 2 3", "rect needs x y width height")
        self.assertTrue(errs[0].startswith("line 2:"))

    def test_many_problems_reported_together_up_to_a_limit(self):
        errs = errors_of("\n".join(f"bogus {i}" for i in range(30)))
        self.assertEqual(len(errs), dsl.MAX_ERRORS)

    def test_various(self):
        self.check("squiggle 1 2", "unknown command 'squiggle'")
        self.check("rect 0 0 10 10 fill=banana", "not a colour")
        self.check("rect 0 0 10 10 colour=red", "no option 'colour'")
        self.check("rect 0 0 -5 10", "must not be negative")
        self.check("rect 0 0 10 10 id=1bad", "id must start with a letter")
        self.check("rect 0 0 10 10 id=a\ncircle 5 5 3 id=a", "used twice")
        self.check("rect 0 0 10 10 fill=url(#nope)", "gradient 'nope' is not defined")
        self.check("group\nrect 0 0 1 1", "never closed")
        self.check("end", "without a matching group")
        self.check("rect 0 0 5 5\ncanvas 100 100", "canvas must come before")
        self.check("canvas 99999 100", "canvas size must be")
        self.check("text 1 2 hello world", "text needs x y")
        self.check("polygon 1,2 3,4", "at least 3 points")
        self.check("polygon 1,2 3,4 5", "pairs")
        self.check('path d="M 0 0 <script>"', "SVG path")
        self.check("path", "path needs d")
        self.check("circle 1e999 0 5", "out of range")
        self.check("circle nan 0 5", "out of range")
        self.check("rect 0 0 10 10 opacity=2", "out of range")
        self.check("rect 0 0 10 10 rotate=abc", "not a number")
        self.check("rect 0 0 10 10 stroke", "rect needs x y width height")
        self.check("circle 5 5 3 stroke=red extra", "unexpected 'extra'")
        self.check("lineargradient g 0 0 0 1 0:red", "at least 2 stops")
        self.check("group\ngroup\ngroup\ngroup\ngroup\nend\nend\nend\nend\nend", "nested at most")

    def test_nothing_is_partially_applied(self):
        model = dsl.new_model()
        try:
            build("rect 0 0 10 10\nrect nope", model)
        except dsl.DrawError:
            pass
        self.assertEqual(model["nodes"], [])

    def test_shape_limit(self):
        script = "\n".join(f"circle {i % 500} {i % 400} 2" for i in range(dsl.MAX_SHAPES + 5))
        self.check(script, "too many shapes")


class Injection(unittest.TestCase):
    """A model steered by hostile text must not be able to put markup into the SVG."""

    def assertClean(self, svg):
        self.assertNotRegex(svg.lower(), r"<script|onload|onerror|onclick|javascript:|<foreignobject|<image|<iframe")
        ET.fromstring(svg)

    def test_text_content_is_escaped(self):
        svg = render('text 5 20 "</text><script>alert(1)</script><text>"')
        self.assertClean(svg)
        self.assertIn("&lt;script&gt;", svg)

    def test_option_values_cannot_break_out_of_attributes(self):
        for script in ['rect 0 0 5 5 fill="red\\" onload=\\"alert(1)"',
                       'rect 0 0 5 5 id="a\\" onload=\\"x"',
                       'text 1 2 "x" font="Arial\\" onload=\\"x"',
                       'path d="M 0 0\\" onload=\\"x"',
                       'rect 0 0 5 5 dash="1\\" onload=\\"x"']:
            errs = errors_of(script)
            self.assertTrue(errs, f"should be rejected: {script}")

    def test_keys_cannot_inject(self):
        self.assertTrue(errors_of('rect 0 0 5 5 onload=alert(1)'))
        self.assertTrue(errors_of('rect 0 0 5 5 href=javascript:alert(1)'))

    def test_url_colour_only_allows_local_gradient_references(self):
        self.assertTrue(errors_of("rect 0 0 5 5 fill=url(http://evil.example/x)"))
        self.assertTrue(errors_of('rect 0 0 5 5 fill="url(#a) onload=1"'))

    def test_control_characters_rejected_in_text(self):
        self.assertTrue(errors_of('text 1 2 "bad\x07bell"'))


class Editing(unittest.TestCase):
    def test_append_adds_on_top_and_keeps_gradients(self):
        m1, _, _ = build("lineargradient g 0 0 0 1 0:red 1:blue\nrect 0 0 50 50 fill=url(#g) id=a")
        m2, _, replaced = build("circle 25 25 10 id=b fill=url(#g)", m1, append=True)
        self.assertEqual([n["id"] for n in m2["nodes"]], ["a", "b"])
        self.assertEqual(replaced, [])

    def test_same_id_replaces_in_place_keeping_z_order(self):
        m1, _, _ = build("rect 0 0 10 10 id=a\nrect 5 5 10 10 id=b\nrect 9 9 10 10 id=c")
        m2, _, replaced = build("circle 50 50 5 id=b fill=red", m1, append=True)
        self.assertEqual([(n["id"], n["type"]) for n in m2["nodes"]], [("a", "rect"), ("b", "circle"), ("c", "rect")])
        self.assertEqual(replaced, ["b"])

    def test_replace_inside_group(self):
        m1, _, _ = build("group id=g\nrect 0 0 5 5 id=inner\nend")
        m2, _, _ = build("circle 2 2 2 id=inner", m1, append=True)
        self.assertEqual(m2["nodes"][0]["children"][0]["type"], "circle")

    def test_original_model_not_mutated_on_error(self):
        m1, _, _ = build("rect 0 0 5 5 id=a")
        before = json.dumps(m1)
        errors_of("rect nope", m1, append=True)
        self.assertEqual(json.dumps(m1), before)

    def test_remove_ids_is_all_or_nothing(self):
        m, _, _ = build("rect 0 0 5 5 id=a\ncircle 1 1 1 id=b")
        removed, missing = dsl.remove_ids(m, ["a", "zzz"])
        self.assertEqual((removed, missing), ([], ["zzz"]))
        self.assertEqual([n["id"] for n in m["nodes"]], ["a", "b"])      # untouched

    def test_removing_a_group_and_its_child_in_one_call(self):
        m, _, _ = build("group id=g\nrect 0 0 5 5 id=in\nend")
        removed, missing = dsl.remove_ids(m, ["g", "in"])
        self.assertEqual(missing, [])
        self.assertEqual(m["nodes"], [])

    def test_remove_ids(self):
        m, _, _ = build("lineargradient g 0 0 0 1 0:red 1:blue\ngroup id=grp\nrect 0 0 5 5 id=in\nend\ncircle 1 1 1 id=c")
        removed, missing = dsl.remove_ids(m, ["in", "c", "g"])
        self.assertEqual(sorted(removed), ["c", "g", "in"])
        self.assertEqual(missing, [])

    def test_auto_ids_never_collide_with_user_ids(self):
        m1, _, _ = build("rect 0 0 5 5 id=s2\nrect 1 1 5 5")
        m2, _, _ = build("rect 2 2 5 5\nrect 3 3 5 5", m1, append=True)
        ids = [n["id"] for n in m2["nodes"]]
        self.assertEqual(len(ids), len(set(ids)))


class Layout(unittest.TestCase):
    def warnings(self, script):
        return build(script)[1]

    def test_inside_is_quiet(self):
        self.assertEqual(self.warnings("canvas 200 200\nrect 0 0 200 200\ncircle 100 100 50"), [])

    def test_off_canvas_and_transformed_groups(self):
        w = self.warnings("canvas 800 500\ngroup translate=80,40 id=boat\nline 60 0 60 -90 stroke=red\nrect 0 0 120 30\nend")
        self.assertTrue(any("group boat" in x and "inside" in x for x in w), w)
        w = self.warnings("canvas 100 100\nrect 500 500 10 10 id=gone")
        self.assertTrue(any("completely outside" in x for x in w), w)

    def test_invisible_shapes(self):
        w = self.warnings("rect 0 0 10 10 fill=none id=a\ncircle 5 5 0 id=b\nrect 0 0 5 5 opacity=0 id=c")
        text = " ".join(w)
        self.assertIn("a (rect) has fill=none", text)
        self.assertIn("zero size", text)
        self.assertIn("opacity=0", text)

    def test_rotation_is_considered(self):
        # a long thin rect rotated into view should not be called "outside"
        self.assertEqual(self.warnings("canvas 200 200\nrect 0 90 200 20 rotate=90"), [])


class Sanitiser(unittest.TestCase):
    GOOD = """<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 200 100">
      <defs><linearGradient id="g"><stop offset="0" stop-color="#fff"/><stop offset="1" stop-color="#000"/></linearGradient>
      <filter id="f"><feGaussianBlur stdDeviation="2"/></filter></defs>
      <rect width="200" height="100" fill="url(#g)" style="stroke:red;stroke-width:2"/>
      <g id="grp" transform="translate(10 10)"><circle id="c" cx="20" cy="20" r="10" filter="url(#f)"/></g>
      <use xlink:href="#c" x="50"/>
      <text x="10" y="90" font-size="14">Hello &amp; salam, dünya 🌅</text></svg>"""

    def clean(self, s):
        out, notes = svgclean.sanitize(s)
        ET.fromstring(out)
        self.assertNotRegex(out.lower(), r"<script|\son\w+=|javascript:")
        return out, notes

    def rejects(self, s, expect):
        with self.assertRaises(svgclean.SvgError) as cm:
            svgclean.sanitize(s)
        self.assertIn(expect, str(cm.exception))

    def test_accepts_typical_svg(self):
        out, notes = self.clean(self.GOOD)
        self.assertIn('width="200"', out)
        self.assertIn("linearGradient", out)
        self.assertIn('href="#c"', out)
        self.assertIn("stroke=\"red\"", out)          # style="..." converted to attributes
        self.assertIn("dünya 🌅", out)

    def test_rejects_dangerous_elements(self):
        for tag in ("script", "style", "foreignObject", "image", "a", "animate", "set", "iframe", "object", "embed"):
            self.rejects(f'<svg viewBox="0 0 50 50" xmlns="http://www.w3.org/2000/svg"><{tag}>x</{tag}></svg>', tag.lower())

    def test_drops_event_handlers_and_external_references(self):
        out, notes = self.clean('<svg viewBox="0 0 50 50" xmlns="http://www.w3.org/2000/svg">'
                                '<rect width="10" height="10" onclick="alert(1)" onmouseover="x()" fill="url(http://evil.example/x)"/>'
                                '<use href="http://evil.example/s.svg#a"/>'
                                '<circle r="3" style="fill:red;background:url(http://evil.example)" fill-opacity="1"/></svg>')
        self.assertNotIn("evil.example", out)
        self.assertNotIn("onclick", out)
        self.assertTrue(notes)

    def test_rejects_entities_doctype_stylesheets(self):
        self.rejects('<!DOCTYPE svg [<!ENTITY a "aaaa">]><svg viewBox="0 0 50 50" xmlns="http://www.w3.org/2000/svg"/>', "DOCTYPE")
        self.rejects('<?xml-stylesheet href="x.css"?><svg viewBox="0 0 50 50" xmlns="http://www.w3.org/2000/svg"/>', "stylesheet")

    def test_structure_errors(self):
        self.rejects("<svg", "well-formed")
        self.rejects('<html xmlns="http://www.w3.org/1999/xhtml"/>', "root element")
        self.rejects('<svg xmlns="http://www.w3.org/2000/svg"><rect width="1" height="1"/></svg>', "viewBox")
        self.rejects('<svg viewBox="0 0 99999 10" xmlns="http://www.w3.org/2000/svg"/>', "between 16 and 4096")
        self.rejects('<svg viewBox="0 0 a b" xmlns="http://www.w3.org/2000/svg"/>', "viewBox")

    def test_size_depth_and_count_limits(self):
        self.rejects("<svg viewBox='0 0 50 50' xmlns='http://www.w3.org/2000/svg'>" + "<g>" * 40 + "</g>" * 40 + "</svg>", "nested")
        many = "<rect width='1' height='1'/>" * (svgclean.MAX_ELEMENTS + 5)
        self.rejects(f"<svg viewBox='0 0 50 50' xmlns='http://www.w3.org/2000/svg'>{many}</svg>", "more than")
        self.rejects("<svg viewBox='0 0 50 50' xmlns='http://www.w3.org/2000/svg'>" + "x" * 600000 + "</svg>", "larger than")

    def test_editor_metadata_is_dropped_quietly(self):
        out, _ = self.clean('<svg viewBox="0 0 50 50" xmlns="http://www.w3.org/2000/svg" xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape" '
                            'xmlns:sodipodi="http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd"><sodipodi:namedview inkscape:zoom="2"/>'
                            '<metadata>junk</metadata><rect width="5" height="5" inkscape:label="x"/></svg>')
        self.assertNotIn("inkscape", out)
        self.assertNotIn("metadata", out)

    def test_size_from_width_height_when_no_viewbox(self):
        out, _ = self.clean('<svg xmlns="http://www.w3.org/2000/svg" width="300px" height="200"><rect width="5" height="5"/></svg>')
        self.assertIn('viewBox="0 0 300 200"', out)


class Tools(unittest.TestCase):
    """Run the tools exactly as the bridge does: manifest validation, argument checks, subprocess."""

    @classmethod
    def setUpClass(cls):
        files = files_from_dir(SKILL)
        cls.manifest, _ = parse_manifest(files)
        cls.tools = {t["name"]: t for t in cls.manifest["tools"]}

    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.proj = Path(self._tmp.name).resolve()

    def tearDown(self):
        self._tmp.cleanup()

    def call(self, tool, **args):
        return run_tool(SKILL, self.tools[tool], args, self.proj)

    def fails(self, tool, expect, **args):
        with self.assertRaises(ToolError) as cm:
            self.call(tool, **args)
        self.assertIn(expect, str(cm.exception))
        return str(cm.exception)

    def test_manifest_is_valid(self):
        self.assertEqual(sorted(self.tools), ["draw", "draw_files", "draw_list", "draw_remove", "draw_svg"])

    def test_full_workflow(self):
        out = self.call("draw", drawing="scene", body="canvas 300 200\nrect 0 0 300 200 fill=skyblue id=sky\ncircle 150 100 40 fill=gold id=sun\n")
        self.assertIn("IMAGE: drawings/scene.svg", out)
        self.assertIn("2 shapes", out)
        svg = (self.proj / "drawings" / "scene.svg").read_text()
        ET.fromstring(svg)
        # inspect
        listing = self.call("draw_list", drawing="scene")
        self.assertIn("sun circle cx=150 cy=100 r=40", listing)
        # edit by id (replace) + add
        out = self.call("draw", drawing="scene", mode="append", body="circle 150 100 80 fill=orange id=sun\ntext 150 190 \"Hi\" anchor=middle")
        self.assertIn("Replaced existing shapes: sun", out)
        self.assertIn("3 shapes", out)
        # remove
        out = self.call("draw_remove", drawing="scene", ids="sky, sun")
        self.assertIn("1 shapes remain", out)
        self.assertIn("scene", self.call("draw_files"))

    def test_errors_save_nothing(self):
        msg = self.fails("draw", "Nothing was saved", drawing="bad", body="rect 1 2\ncircle x y z")
        self.assertIn("line 1", msg)
        self.assertIn("line 2", msg)
        self.assertFalse((self.proj / "drawings" / "bad.svg").exists())

    def test_append_requires_existing_drawing(self):
        self.fails("draw", "no drawing called", drawing="ghost", mode="append", body="rect 0 0 1 1")

    def test_draw_remove_unknown_id_changes_nothing_and_lists_ids(self):
        self.call("draw", drawing="d", body="rect 0 0 5 5 id=a")
        msg = self.fails("draw_remove", "no shape or gradient with id: zzz", drawing="d", ids="a,zzz")
        self.assertIn("Existing ids: a", msg)
        self.assertIn("a rect", self.call("draw_list", drawing="d"))

    def test_cannot_remove_a_gradient_that_is_in_use(self):
        self.call("draw", drawing="d", body="lineargradient g 0 0 0 1 0:red 1:blue\nrect 0 0 5 5 fill=url(#g) id=a")
        self.fails("draw_remove", "still uses it", drawing="d", ids="g")

    def test_raw_svg_flow(self):
        out = self.call("draw_svg", drawing="raw", body='<svg viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg"><circle cx="32" cy="32" r="20" fill="red" onclick="x()"/></svg>')
        self.assertIn("IMAGE: drawings/raw.svg", out)
        self.assertIn("removed unsafe", out)
        self.assertNotIn("onclick", (self.proj / "drawings" / "raw.svg").read_text())
        self.fails("draw_list", "raw SVG", drawing="raw")
        self.fails("draw", "raw SVG", drawing="raw", mode="append", body="rect 0 0 1 1")
        self.assertIn("raw SVG", self.call("draw_files"))
        self.fails("draw_svg", "not allowed", drawing="evil", body='<svg viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg"><script>alert(1)</script></svg>')
        self.assertFalse((self.proj / "drawings" / "evil.svg").exists())

    def test_redrawing_as_dsl_replaces_a_raw_svg(self):
        self.call("draw_svg", drawing="x", body='<svg viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg"><rect width="5" height="5"/></svg>')
        self.call("draw", drawing="x", body="rect 0 0 9 9")
        self.assertIn("1 shapes", self.call("draw_list", drawing="x").replace("1 shapes", "1 shapes"))

    def test_bad_names_and_arguments(self):
        for bad in ("../escape", "a/b", "A", "x" * 60, "-x", "a b", ".hidden"):
            self.fails("draw", "name must be", drawing=bad, body="rect 0 0 1 1")
        self.fails("draw", "must be one of: new, append", drawing="ok", mode="bogus", body="rect 0 0 1 1")
        self.fails("draw", "missing required parameter 'drawing'", body="rect 0 0 1 1")
        self.fails("draw", "needs a =====BODY=====", drawing="ok")

    def test_refuses_to_write_through_a_symlinked_drawings_folder(self):
        outside = tempfile.TemporaryDirectory()
        try:
            os.symlink(outside.name, self.proj / "drawings")
        except (OSError, NotImplementedError):
            self.skipTest("symlinks unavailable")
        try:
            self.fails("draw", "outside the project", drawing="x", body="rect 0 0 1 1")
            self.assertEqual(os.listdir(outside.name), [])
        finally:
            outside.cleanup()

    def test_unicode_roundtrip_through_the_tool(self):
        self.call("draw", drawing="u", body='text 10 30 "Azərbaycan 🌅 你好"')
        self.assertIn("Azərbaycan 🌅 你好", (self.proj / "drawings" / "u.svg").read_text(encoding="utf-8"))


if __name__ == "__main__":
    unittest.main()
