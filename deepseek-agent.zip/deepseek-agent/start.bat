@echo off
setlocal
title DeepSeek Agent bridge
rem Usage: drag a project folder onto this file, or double-click and type the path.
set "ROOT=%~1"
if "%ROOT%"=="" set /p ROOT=Project folder to give the agent: 
set "ROOT=%ROOT:"=%"
if not exist "%ROOT%\" (
  echo.
  echo Folder not found: %ROOT%
  pause
  exit /b 1
)
where python >nul 2>nul && (set "PY=python") || (set "PY=py")
%PY% "%~dp0bridge\bridge.py" --root "%ROOT%"
echo.
pause
